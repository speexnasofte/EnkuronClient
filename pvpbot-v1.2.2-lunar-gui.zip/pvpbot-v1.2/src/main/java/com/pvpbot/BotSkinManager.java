package com.pvpbot;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * BotSkinManager — загружает скин игрока по нику и регистрирует
 * его как текстуру для BotEntityRenderer.
 *
 * Флоу:
 *   1. /bot spawn <nick>  →  BotSkinManager.fetchSkin(nick)
 *   2. GET api.mojang.com → UUID
 *   3. GET sessionserver  → base64 profile → skinUrl
 *   4. GET skinUrl        → PNG → NativeImageBackedTexture
 *   5. TextureManager.registerTexture("pvpbot:skin/<uuid>")
 *   6. BotEntity.setSkinId(nick) → рендерер берёт текстуру
 *
 * Всё сетевое — в отдельном потоке (CompletableFuture).
 * Регистрация текстуры — в main thread через pending queue.
 */
public class BotSkinManager {

    public static final BotSkinManager INSTANCE = new BotSkinManager();

    // nick (lowercase) → Identifier текстуры (null пока грузится)
    private final Map<String, Identifier> skinCache = new ConcurrentHashMap<>();

    // Pending: текстуры ожидают регистрации в main thread
    private record PendingTexture(String nick, NativeImage image) {}
    private final java.util.concurrent.ConcurrentLinkedQueue<PendingTexture> pending =
        new java.util.concurrent.ConcurrentLinkedQueue<>();

    private BotSkinManager() {}

    /**
     * Регистрирует тик-хук для main-thread регистрации текстур.
     * Вызывать из PVPBotMod.onInitializeClient().
     */
    public void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            PendingTexture pt;
            while ((pt = pending.poll()) != null) {
                registerTexture(client, pt.nick(), pt.image());
            }
        });
    }

    /**
     * Возвращает Identifier текстуры для ника.
     * Если скин ещё грузится — возвращает null (рендерер покажет дефолт).
     * Если скин уже загружен — возвращает кешированный.
     * Если ещё не начали — запускает загрузку.
     */
    public Identifier getSkinTexture(String nick) {
        if (nick == null || nick.isEmpty()) return null;
        String key = nick.toLowerCase();

        if (skinCache.containsKey(key)) {
            return skinCache.get(key); // может быть null если грузится
        }

        // Начинаем загрузку, ставим null-маркер "в процессе"
        skinCache.put(key, null);
        fetchSkinAsync(key);
        return null;
    }

    /**
     * Принудительно запустить загрузку скина заранее (при спавне бота).
     */
    public void prefetch(String nick) {
        if (nick == null || nick.isEmpty()) return;
        String key = nick.toLowerCase();
        if (!skinCache.containsKey(key)) {
            skinCache.put(key, null);
            fetchSkinAsync(key);
        }
    }

    // ── Внутренние методы ────────────────────────────────────────

    private void fetchSkinAsync(String nick) {
        CompletableFuture.runAsync(() -> {
            try {
                // Шаг 1: ник → UUID
                String uuid = fetchUUID(nick);
                if (uuid == null) {
                    System.err.println("[PVPBot] Не найден игрок: " + nick);
                    return;
                }

                // Шаг 2: UUID → skin URL
                String skinUrl = fetchSkinUrl(uuid);
                if (skinUrl == null) {
                    System.err.println("[PVPBot] Нет скина у: " + nick);
                    return;
                }

                // Шаг 3: скачать PNG
                NativeImage image = downloadImage(skinUrl);
                if (image == null) {
                    System.err.println("[PVPBot] Не удалось скачать скин: " + skinUrl);
                    return;
                }

                // Шаг 4: передать в main thread
                pending.add(new PendingTexture(nick, image));

            } catch (Exception e) {
                System.err.println("[PVPBot] Ошибка загрузки скина '" + nick + "': " + e.getMessage());
            }
        });
    }

    private String fetchUUID(String nick) throws Exception {
        HttpURLConnection conn = openConnection(
            "https://api.mojang.com/users/profiles/minecraft/" + nick);
        if (conn.getResponseCode() != 200) return null;

        try (InputStreamReader r = new InputStreamReader(conn.getInputStream())) {
            JsonObject obj = JsonParser.parseReader(r).getAsJsonObject();
            String rawId = obj.get("id").getAsString();
            // Вставляем дефисы: 8-4-4-4-12
            return rawId.replaceFirst(
                "(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})",
                "$1-$2-$3-$4-$5"
            );
        }
    }

    private String fetchSkinUrl(String uuid) throws Exception {
        HttpURLConnection conn = openConnection(
            "https://sessionserver.mojang.com/session/minecraft/profile/" +
            uuid.replace("-", ""));
        if (conn.getResponseCode() != 200) return null;

        try (InputStreamReader r = new InputStreamReader(conn.getInputStream())) {
            JsonObject profile = JsonParser.parseReader(r).getAsJsonObject();
            var props = profile.getAsJsonArray("properties");
            for (var el : props) {
                JsonObject prop = el.getAsJsonObject();
                if ("textures".equals(prop.get("name").getAsString())) {
                    String decoded = new String(
                        Base64.getDecoder().decode(prop.get("value").getAsString()));
                    JsonObject tex = JsonParser.parseString(decoded)
                        .getAsJsonObject()
                        .getAsJsonObject("textures");
                    if (tex.has("SKIN")) {
                        return tex.getAsJsonObject("SKIN").get("url").getAsString();
                    }
                }
            }
        }
        return null;
    }

    private NativeImage downloadImage(String url) throws Exception {
        HttpURLConnection conn = openConnection(url);
        if (conn.getResponseCode() != 200) return null;
        try (InputStream is = conn.getInputStream()) {
            return NativeImage.read(is);
        }
    }

    private HttpURLConnection openConnection(String url) throws Exception {
        HttpURLConnection conn = (HttpURLConnection)
            URI.create(url).toURL().openConnection();
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);
        conn.setRequestProperty("User-Agent", "PVPBot-Fabric/9");
        return conn;
    }

    private void registerTexture(MinecraftClient client, String nick, NativeImage image) {
        try {
            Identifier id = Identifier.of("pvpbot", "skin/" + nick);
            client.getTextureManager().registerTexture(id,
                new NativeImageBackedTexture(image));
            skinCache.put(nick, id);
            System.out.println("[PVPBot] Скин загружен: " + nick + " → " + id);
        } catch (Exception e) {
            System.err.println("[PVPBot] Ошибка регистрации текстуры: " + e.getMessage());
        }
    }

    /** Fallback текстура (дефолтный зомби). */
    public static final Identifier DEFAULT_TEXTURE =
        Identifier.of("minecraft", "textures/entity/zombie/zombie.png");
}
