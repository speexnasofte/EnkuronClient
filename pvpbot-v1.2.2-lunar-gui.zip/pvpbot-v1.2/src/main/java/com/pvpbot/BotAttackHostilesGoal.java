package com.pvpbot;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.mob.HostileEntity;

/**
 * Бот атакует враждебных мобов (зомби, скелеты и т.д.) в режимах GUARD и AGGRESSIVE.
 */
public class BotAttackHostilesGoal extends ActiveTargetGoal<HostileEntity> {

    private final BotEntity bot;

    public BotAttackHostilesGoal(BotEntity bot) {
        super(bot, HostileEntity.class, true);
        this.bot = bot;
    }

    @Override
    public boolean canStart() {
        if (bot.getBotMode() == BotEntity.BotMode.PASSIVE) return false;
        return super.canStart();
    }
}
