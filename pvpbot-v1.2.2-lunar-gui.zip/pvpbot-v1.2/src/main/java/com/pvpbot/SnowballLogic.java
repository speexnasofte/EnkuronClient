package com.pvpbot;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Vec3d;

/**
 * SnowballLogic — v16: режим SNOWBALL.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Тактика:
 * ══════════════════════════════════════════════════════════════════
 *
 *  Снежок сам по себе не наносит урона, но:
 *  - Сбивает прицел (knockback на лук)
 *  - Сбрасывает щит на 1 тик (открывает для удара)
 *  - Отвлекает: противник оборачивается, открывая спину
 *
 *  FSM:
 *
 *  STRAFE → бот отходит/кружит, бросает снежки на расстоянии
 *  SHIELD_BREAK → если цель держит щит — серия из 3 снежков,
 *                 потом немедленная атака мечом (RUSH)
 *  RUSH → сближается и бьёт мечом 1-2 раза, уходит назад
 *  COOLDOWN → пауза перед следующей серией
 *
 * ══════════════════════════════════════════════════════════════════
 *  Детали реализации:
 * ══════════════════════════════════════════════════════════════════
 *
 *  Снежок спауним как ThrownEntity с нужной скоростью-вектором.
 *  Aim-prediction: добавляем к позиции цели её velocity * LEAD_TICKS.
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class SnowballLogic {

    // ── Константы ─────────────────────────────────────────────────
    private static final double THROW_RANGE     = 12.0;  // дальность броска
    private static final double RUSH_RANGE      = 3.8;   // дистанция атаки мечом
    private static final double STRAFE_DIST     = 7.0;   // держим эту дистанцию
    private static final int    SNOWBALL_CD     = 15;    // тиков между снежками
    private static final int    RUSH_CD         = 10;    // кулдаун удара мечом
    private static final int    COOLDOWN_TICKS  = 30;    // пауза между сериями
    private static final int    SHIELD_BURST    = 3;     // снежков для сбивания щита
    private static final float  SNOWBALL_SPEED  = 1.5f;
    private static final int    LEAD_TICKS      = 4;     // упреждение при броске

    // ── Состояния ─────────────────────────────────────────────────
    private enum State { STRAFE, SHIELD_BREAK, RUSH, COOLDOWN }
    private State state        = State.STRAFE;
    private int   snowballCd   = 0;
    private int   rushCd       = 0;
    private int   cooldownTimer = 0;
    private int   burstCount   = 0;   // снежков в текущей серии

    private final BotEntity bot;

    public SnowballLogic(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Главный тик
    // ══════════════════════════════════════════════════════════════
    public void tick(LivingEntity target) {
        if (!(bot.getWorld() instanceof ServerWorld sw)) return;
        if (target == null || !target.isAlive()) return;

        if (snowballCd > 0) snowballCd--;
        if (rushCd     > 0) rushCd--;

        switch (state) {
            case STRAFE        -> tickStrafe(sw, target);
            case SHIELD_BREAK  -> tickShieldBreak(sw, target);
            case RUSH          -> tickRush(sw, target);
            case COOLDOWN      -> tickCooldown(sw, target);
        }
    }

    // ── STRAFE: кружим, периодически бросаем снежки ───────────────
    private void tickStrafe(ServerWorld sw, LivingEntity target) {
        double dist = bot.distanceTo(target);

        // Держим дистанцию кайтингом
        if (dist < STRAFE_DIST - 1.0) {
            Vec3d away = bot.getPos().subtract(target.getPos()).normalize().multiply(2.0);
            Vec3d dest = bot.getPos().add(away);
            bot.getNavigation().startMovingTo(dest.x, dest.y, dest.z, 1.25);
        } else if (dist > THROW_RANGE) {
            bot.getNavigation().startMovingTo(target, 1.1);
        }

        // Бросаем снежки
        if (dist <= THROW_RANGE && snowballCd <= 0) {
            throwSnowball(sw, target);
            snowballCd = SNOWBALL_CD;
        }

        // Если цель держит щит — переходим к SHIELD_BREAK
        if (isHoldingShield(target)) {
            state = State.SHIELD_BREAK;
            burstCount = 0;
        }

        // Иногда делаем RUSH для разнообразия (каждые ~3 сек)
        if (snowballCd <= 0 && Math.random() < 0.008 && dist <= RUSH_RANGE + 1.0) {
            state = State.RUSH;
        }
    }

    // ── SHIELD_BREAK: серия снежков → ломаем щит → RUSH ──────────
    private void tickShieldBreak(ServerWorld sw, LivingEntity target) {
        double dist = bot.distanceTo(target);

        // Сближаемся до хорошей дистанции для броска
        if (dist > 6.0) {
            bot.getNavigation().startMovingTo(target, 1.2);
        }

        if (dist <= THROW_RANGE && snowballCd <= 0) {
            throwSnowball(sw, target);
            snowballCd = 8; // ускоренная серия для сбивания щита
            burstCount++;
        }

        if (burstCount >= SHIELD_BURST) {
            // После серии — немедленная атака мечом
            state = State.RUSH;
            burstCount = 0;
        }

        // Цель убрала щит — тоже RUSH
        if (!isHoldingShield(target)) {
            state = State.RUSH;
            burstCount = 0;
        }
    }

    // ── RUSH: сближаемся, атакуем мечом ──────────────────────────
    private void tickRush(ServerWorld sw, LivingEntity target) {
        double dist = bot.distanceTo(target);

        if (dist > RUSH_RANGE) {
            bot.getNavigation().startMovingTo(target, 1.45);
        } else {
            // Атакуем
            if (rushCd <= 0) {
                equipSword(sw);
                bot.tryAttack(target);
                rushCd = RUSH_CD;
                // После удара — откатываемся
                state = State.COOLDOWN;
                cooldownTimer = COOLDOWN_TICKS;
                Vec3d away = bot.getPos().subtract(target.getPos()).normalize().multiply(4.0);
                Vec3d dest = bot.getPos().add(away);
                bot.getNavigation().startMovingTo(dest.x, dest.y, dest.z, 1.4);
            }
        }
    }

    // ── COOLDOWN: пауза, уходим назад ────────────────────────────
    private void tickCooldown(ServerWorld sw, LivingEntity target) {
        cooldownTimer--;
        if (cooldownTimer <= 0) {
            state = State.STRAFE;
        }
    }

    // ── Бросаем снежок с упреждением ─────────────────────────────
    private void throwSnowball(ServerWorld sw, LivingEntity target) {
        // Упреждение: позиция + velocity * LEAD_TICKS
        Vec3d lead = target.getPos()
            .add(target.getVelocity().multiply(LEAD_TICKS))
            .add(0, target.getHeight() * 0.5, 0); // по центру тела

        Vec3d from = bot.getPos().add(0, bot.getEyeHeight(bot.getPose()), 0);
        Vec3d dir  = lead.subtract(from).normalize();

        SnowballEntity snowball = new SnowballEntity(sw, bot);
        snowball.setVelocity(
            dir.x * SNOWBALL_SPEED,
            dir.y * SNOWBALL_SPEED + 0.05, // небольшой arc
            dir.z * SNOWBALL_SPEED
        );
        sw.spawnEntity(snowball);

        sw.playSound(null, bot.getX(), bot.getY(), bot.getZ(),
            SoundEvents.ENTITY_SNOWBALL_THROW,
            SoundCategory.NEUTRAL, 0.5f, 0.4f / (sw.random.nextFloat() * 0.4f + 0.8f));
    }

    // ── Определить держит ли цель щит ────────────────────────────
    private boolean isHoldingShield(LivingEntity target) {
        ItemStack main = target.getMainHandStack();
        ItemStack off  = target.getOffHandStack();
        return main.isOf(Items.SHIELD) || off.isOf(Items.SHIELD);
    }

    // ── Экипировать меч ──────────────────────────────────────────
    private void equipSword(ServerWorld sw) {
        ItemStack main = bot.getEquippedStack(net.minecraft.entity.EquipmentSlot.MAINHAND);
        if (!main.isOf(Items.DIAMOND_SWORD) && !main.isOf(Items.NETHERITE_SWORD)) {
            bot.equipStack(net.minecraft.entity.EquipmentSlot.MAINHAND,
                new ItemStack(Items.DIAMOND_SWORD));
        }
    }

    // ── Статус ────────────────────────────────────────────────────
    public String getStateLabel() {
        return switch (state) {
            case STRAFE       -> "SNOW:KITE";
            case SHIELD_BREAK -> "SNOW:BURST x" + burstCount;
            case RUSH         -> "SNOW:RUSH";
            case COOLDOWN     -> "SNOW:CD " + cooldownTimer + "t";
        };
    }
}
