package com.pvpbot;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.FireworkRocketItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundEvents;
import net.minecraft.component.DataComponentTypes;

/**
 * FireworkLogic — v14: режим FIREWORK.
 *
 * Механика:
 *   1. Бот надевает элитры (CHEST слот) и использует их для уклонения.
 *   2. Запускает фейерверки-ракеты направленно в цель (взрывной урон).
 *   3. Dash-уклонение через элитры + фейерверк-ускоритель.
 *   4. Чередует: залп фейерверков → dash-уклонение → снова залп.
 *
 * Совместимость: 1.21.11
 */
public class FireworkLogic {

    private static final int FIREWORK_COOLDOWN = 25;  // тиков между ракетами
    private static final int BURST_COUNT       = 3;   // ракет в залпе
    private static final int BURST_INTERVAL    = 4;   // тиков между ракетами залпа
    private static final double LAUNCH_RANGE   = 12.0;
    private static final int DASH_COOLDOWN     = 60;

    private int fireworkTimer = 0;
    private int dashTimer     = 0;
    private int burstLeft     = 0;
    private int burstTick     = 0;
    private LivingEntity burstTarget = null;

    private final BotEntity bot;

    public FireworkLogic(BotEntity bot) {
        this.bot = bot;
    }

    public void tick(LivingEntity target) {
        if (!(bot.getWorld() instanceof ServerWorld sw)) return;
        if (target == null || !target.isAlive()) return;

        if (fireworkTimer > 0) fireworkTimer--;
        if (dashTimer > 0)     dashTimer--;

        equipFireworkKit();

        double dist = bot.distanceTo(target);

        // ── Burst залп ────────────────────────────────────────────
        if (burstLeft > 0) {
            burstTick--;
            if (burstTick <= 0) {
                launchFireworkAt(sw, burstTarget);
                burstLeft--;
                burstTick = BURST_INTERVAL;
            }
            return;
        }

        // ── Запустить новый залп ──────────────────────────────────
        if (dist <= LAUNCH_RANGE && fireworkTimer <= 0) {
            burstLeft  = BURST_COUNT;
            burstTick  = 1;
            burstTarget = target;
            fireworkTimer = FIREWORK_COOLDOWN;
        }

        // ── Элитра-даш для уклонения ──────────────────────────────
        if (dashTimer <= 0 && bot.getHealth() < bot.getMaxHealth() * 0.6) {
            elytraDash(sw, target);
            dashTimer = DASH_COOLDOWN;
        }

        // ── Движение ──────────────────────────────────────────────
        if (dist > 6.0) {
            bot.getNavigation().startMovingTo(target, 1.2);
        } else if (dist < 4.0) {
            // Держим дистанцию — отходим чуть назад
            Vec3d away = bot.getPos().subtract(target.getPos()).normalize().multiply(0.4);
            bot.setVelocity(bot.getVelocity().add(away.x, 0, away.z));
            bot.velocityModified = true;
        }
    }

    private void launchFireworkAt(ServerWorld sw, LivingEntity target) {
        // Создаём ItemStack фейерверка с зарядом
        ItemStack rocket = new ItemStack(Items.FIREWORK_ROCKET);
        // Вектор направления к цели
        Vec3d dir = target.getEyePos().subtract(bot.getEyePos()).normalize();

        // Спавним снаряд фейерверка
        FireworkRocketEntity firework = new FireworkRocketEntity(
            sw, bot, bot.getX(), bot.getEyeY(), bot.getZ(), rocket
        );
        // Задаём скорость в сторону цели
        firework.setVelocity(dir.x * 1.5, dir.y * 1.5, dir.z * 1.5);
        sw.spawnEntity(firework);

        // Эффекты
        sw.spawnParticles(ParticleTypes.FIREWORK,
            bot.getX(), bot.getY() + 1, bot.getZ(),
            5, 0.2, 0.2, 0.2, 0.1);
        bot.playSound(SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, 1.0f, 1.0f);
    }

    private void elytraDash(ServerWorld sw, LivingEntity target) {
        // Импульс уклонения — в сторону от цели + вверх
        Vec3d toTarget = target.getPos().subtract(bot.getPos()).normalize();
        Vec3d sideDir  = new Vec3d(-toTarget.z, 0.4, toTarget.x).normalize().multiply(0.8);
        bot.setVelocity(bot.getVelocity().add(sideDir));
        bot.velocityModified = true;

        sw.spawnParticles(ParticleTypes.CLOUD,
            bot.getX(), bot.getY(), bot.getZ(),
            8, 0.3, 0.1, 0.3, 0.05);
    }

    private void equipFireworkKit() {
        // Элитры в нагрудник
        ItemStack chest = bot.getEquippedStack(EquipmentSlot.CHEST);
        if (!chest.isOf(Items.ELYTRA)) {
            bot.equipStack(EquipmentSlot.CHEST, new ItemStack(Items.ELYTRA));
        }
        // Меч в руку
        ItemStack main = bot.getEquippedStack(EquipmentSlot.MAINHAND);
        if (main.isEmpty()) {
            bot.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
        }
        // Шлем/ноги/ботинки
        if (bot.getEquippedStack(EquipmentSlot.HEAD).isEmpty())
            bot.equipStack(EquipmentSlot.HEAD, new ItemStack(Items.NETHERITE_HELMET));
        if (bot.getEquippedStack(EquipmentSlot.LEGS).isEmpty())
            bot.equipStack(EquipmentSlot.LEGS, new ItemStack(Items.NETHERITE_LEGGINGS));
        if (bot.getEquippedStack(EquipmentSlot.FEET).isEmpty())
            bot.equipStack(EquipmentSlot.FEET, new ItemStack(Items.NETHERITE_BOOTS));
    }
}
