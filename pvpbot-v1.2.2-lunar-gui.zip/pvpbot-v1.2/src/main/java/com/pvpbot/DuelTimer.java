package com.pvpbot;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

import java.util.UUID;

/**
 * DuelTimer — v16: таймер раундов дуэли.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Команды:
 * ══════════════════════════════════════════════════════════════════
 *
 *  /bot duel start [минут]    — начать дуэль (дефолт 5 мин)
 *  /bot duel stop             — остановить дуэль
 *  /bot duel score            — показать счёт
 *  /bot duel round [N]        — сыграть N раундов (дефолт 3)
 *
 * ══════════════════════════════════════════════════════════════════
 *  Логика:
 * ══════════════════════════════════════════════════════════════════
 *
 *  - Дуэль разбита на раунды. Раунд заканчивается когда один
 *    из участников умирает.
 *  - Счёт: kills бота vs kills цели.
 *  - По истечении времени или всех раундов — объявляется победитель.
 *  - Каждые 60 сек бот пишет в чат оставшееся время.
 *  - При победе бота: «§c⚔ Бот победил в дуэли! Счёт N:M»
 *  - При победе игрока: «§a🏆 Игрок победил! Счёт N:M»
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class DuelTimer {

    public static final DuelTimer INSTANCE = new DuelTimer();

    // ── Состояние ─────────────────────────────────────────────────
    private boolean active        = false;
    private int     ticksLeft     = 0;
    private int     totalRounds   = 3;
    private int     currentRound  = 0;
    private int     botKills      = 0;
    private int     playerKills   = 0;
    private int     announceTimer = 0;

    private UUID    ownerUUID     = null;
    private String  opponentName  = null;

    // ── Публичный API ─────────────────────────────────────────────

    /** Начать дуэль. minutes=0 → без таймера (только раунды) */
    public void start(int minutes, int rounds, UUID ownerUUID, String opponentName) {
        this.active       = true;
        this.ticksLeft    = minutes > 0 ? minutes * 60 * 20 : Integer.MAX_VALUE;
        this.totalRounds  = rounds;
        this.currentRound = 1;
        this.botKills     = 0;
        this.playerKills  = 0;
        this.announceTimer = 0;
        this.ownerUUID    = ownerUUID;
        this.opponentName = opponentName != null ? opponentName : "Игрок";
    }

    public void stop() {
        active = false;
        broadcast(null, "§7Дуэль остановлена. Финал: §f" + botKills + "§7:§f" + playerKills);
    }

    public boolean isActive() { return active; }

    // ── Вызывать каждый тик от PVPBotMod.serverTick() ────────────
    public void tick(MinecraftServer server) {
        if (!active) return;

        ticksLeft--;
        announceTimer++;

        // Оповещение каждые 60 сек
        if (announceTimer >= 60 * 20) {
            announceTimer = 0;
            if (ticksLeft != Integer.MAX_VALUE) {
                int secsLeft = ticksLeft / 20;
                broadcast(server, String.format(
                    "§6⚔ Дуэль: §fРаунд %d/%d §7| Счёт §c%d§7:§a%d §7| Осталось §f%d:%02d",
                    currentRound, totalRounds, botKills, playerKills,
                    secsLeft / 60, secsLeft % 60));
            }
        }

        // Время вышло
        if (ticksLeft <= 0) {
            endDuel(server);
        }
    }

    // ── Бот убил игрока ───────────────────────────────────────────
    public void onBotKill(MinecraftServer server) {
        if (!active) return;
        botKills++;
        endRound(server, true);
    }

    // ── Игрок убил бота ──────────────────────────────────────────
    public void onPlayerKill(MinecraftServer server) {
        if (!active) return;
        playerKills++;
        endRound(server, false);
    }

    // ── Раунд завершён ────────────────────────────────────────────
    private void endRound(MinecraftServer server, boolean botWon) {
        String winner = botWon ? "§cБот" : "§a" + opponentName;
        broadcast(server, String.format(
            "§6⚔ Раунд %d: %s §6победил! §7Счёт §c%d§7:§a%d",
            currentRound, winner, botKills, playerKills));

        currentRound++;
        announceTimer = 0;

        if (currentRound > totalRounds) {
            endDuel(server);
        } else {
            broadcast(server, "§7Раунд " + currentRound + " из " + totalRounds + " начнётся через 5 секунд...");
        }
    }

    // ── Дуэль завершена ───────────────────────────────────────────
    private void endDuel(MinecraftServer server) {
        active = false;

        String result;
        if (botKills > playerKills) {
            result = "§c⚔ Бот победил в дуэли!";
        } else if (playerKills > botKills) {
            result = "§a🏆 " + opponentName + " победил!";
        } else {
            result = "§e🤝 Ничья!";
        }

        broadcast(server, result + " §7Финальный счёт: §c" + botKills + "§7:§a" + playerKills);
    }

    // ── Текст для /bot duel score ─────────────────────────────────
    public String getScoreText() {
        if (!active) return "§7Дуэль не идёт. Используй §f/bot duel start";
        int secsLeft = ticksLeft == Integer.MAX_VALUE ? -1 : ticksLeft / 20;
        String timer = secsLeft < 0 ? "∞"
            : String.format("%d:%02d", secsLeft / 60, secsLeft % 60);
        return String.format("§6⚔ Дуэль: §fРаунд %d/%d §7| §c%d§7:§a%d §7| ⏱ §f%s",
            currentRound, totalRounds, botKills, playerKills, timer);
    }

    // ── Оповещение ───────────────────────────────────────────────
    private void broadcast(MinecraftServer server, String msg) {
        if (server != null) {
            for (var player : server.getPlayerManager().getPlayerList()) {
                player.sendMessage(Text.literal(msg), false);
            }
        }
        System.out.println("[DuelTimer] " + msg.replaceAll("§.", ""));
    }

    // ── Геттеры ──────────────────────────────────────────────────
    public int getBotKills()    { return botKills;    }
    public int getPlayerKills() { return playerKills; }
    public int getCurrentRound(){ return currentRound;}
    public int getTotalRounds() { return totalRounds; }
    public int getSecsLeft()    { return ticksLeft == Integer.MAX_VALUE ? -1 : ticksLeft / 20; }
}
