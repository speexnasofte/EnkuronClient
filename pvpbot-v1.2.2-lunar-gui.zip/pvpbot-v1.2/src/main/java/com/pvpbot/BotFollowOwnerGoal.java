package com.pvpbot;

import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

import java.util.EnumSet;

/**
 * Бот следует за владельцем, если расстояние > maxDist.
 * Прекращает следовать, если расстояние < minDist.
 */
public class BotFollowOwnerGoal extends Goal {

    private final BotEntity bot;
    private final double speed;
    private final float maxDist;
    private final float minDist;
    private PlayerEntity owner;
    private int timer;

    public BotFollowOwnerGoal(BotEntity bot, double speed, float maxDist, float minDist) {
        this.bot = bot;
        this.speed = speed;
        this.maxDist = maxDist;
        this.minDist = minDist;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        // Не следуем если есть цель (идём в бой)
        if (bot.getTarget() != null) return false;
        owner = bot.getOwner();
        if (owner == null) return false;
        return owner.squaredDistanceTo(bot) > (maxDist * maxDist);
    }

    @Override
    public boolean shouldContinue() {
        if (bot.getTarget() != null) return false;
        if (owner == null) return false;
        return owner.squaredDistanceTo(bot) > (minDist * minDist);
    }

    @Override
    public void start() {
        timer = 0;
    }

    @Override
    public void stop() {
        bot.getNavigation().stop();
    }

    @Override
    public void tick() {
        bot.getLookControl().lookAt(owner, 10.0f, bot.getMaxLookPitchChange());
        if (--timer <= 0) {
            timer = 10;
            double dist = bot.distanceTo(owner);
            if (dist > maxDist) {
                // Formations v10: получаем смещённую целевую позицию
                Vec3d target = getFormationTarget();
                if (dist > 64.0) {
                    bot.teleport(target.x, target.y, target.z);
                } else {
                    bot.getNavigation().startMovingTo(target.x, target.y, target.z, speed);
                }
            }
        }
    }

    /** Возвращает целевую точку с учётом текущего построения. */
    private Vec3d getFormationTarget() {
        // Определяем индекс этого бота среди ботов владельца
        // Простое решение: индекс 0 (одиночный бот или первый в списке)
        // Полный индекс требует доступа к списку SpawnBotCommand — упрощаем до 0
        return BotFormations.INSTANCE.getTargetPos(bot, 0, 1, owner);
    }
}
