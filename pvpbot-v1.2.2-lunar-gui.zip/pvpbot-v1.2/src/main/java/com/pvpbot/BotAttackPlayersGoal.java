package com.pvpbot;

import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Атакует других игроков — только в режиме AGGRESSIVE.
 * Владелец никогда не является целью.
 */
public class BotAttackPlayersGoal extends ActiveTargetGoal<PlayerEntity> {

    private final BotEntity bot;

    public BotAttackPlayersGoal(BotEntity bot) {
        super(bot, PlayerEntity.class, true);
        this.bot = bot;
    }

    @Override
    public boolean canStart() {
        if (bot.getBotMode() != BotEntity.BotMode.AGGRESSIVE) return false;
        var owner = bot.getOwner();
        // Ищем ближайшего игрока, исключая владельца
        return super.canStart();
    }

    @Override
    protected boolean isTargetValid(PlayerEntity target) {
        var owner = bot.getOwner();
        if (owner != null && target.getUuid().equals(owner.getUuid())) return false;
        return super.isTargetValid(target);
    }
}
