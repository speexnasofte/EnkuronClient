package com.pvpbot.client;

import com.pvpbot.AutoLog;
import com.pvpbot.BotEntityType;
import com.pvpbot.BotSkinManager;
import com.pvpbot.Tracers;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

/**
 * Регистрирует рендерер бота на клиенте.
 * Вынесен отдельно чтобы не грузить серверные окружения.
 */
public class BotClientInit implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(
            BotEntityType.BOT_ENTITY,
            BotEntityRenderer::new
        );
        // v9: регистрируем тик-хук для загрузки скинов
        BotSkinManager.INSTANCE.register();

        // v11: AutoLog — выход по HP
        AutoLog.INSTANCE.register();

        // v11: Tracers — линии к сущностям
        Tracers.INSTANCE.register();
    }
}
