package com.pvpbot;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

/**
 * TrainingMode — v14: Обучающий режим PvP.
 *
 * Бот переходит в режим тренера:
 *   - Атакует слабо (не убивает), HP игрока не падает ниже порога
 *   - Подсказывает в чат когда и как делать крит/w-tap
 *   - Показывает тайминг атаки (когда кулдаун = 100%)
 *   - Комментирует ошибки игрока (бьёт не в крит, не делает w-tap)
 *
 * Активация: /bot train [on|off]
 */
public class TrainingMode {

    public static final TrainingMode INSTANCE = new TrainingMode();

    private boolean active = false;

    // Состояние
    private int tipCooldown    = 0;
    private int phaseTimer     = 0;
    private int currentPhase   = 0; // 0=крит, 1=w-tap, 2=страф
    private static final int PHASE_DURATION = 200; // тиков на фазу

    // Минимальный HP игрока в тренировочном режиме (не даём убить)
    private static final float MIN_PLAYER_HP = 6.0f;
    private static final int   TIP_INTERVAL  = 60;  // тиков между подсказками

    private TrainingMode() {}

    public void setActive(boolean v) { this.active = v; }
    public boolean isActive()        { return active; }
    public void toggle()             { active = !active; }

    /**
     * Тик тренировочного режима на сервере.
     * Вызывается из BotEntity.tick() если режим включён.
     *
     * @param bot    бот-тренер
     * @param target цель (должна быть игрок-ученик)
     */
    public void tick(BotEntity bot, LivingEntity target) {
        if (!active || target == null) return;
        if (!(bot.getWorld() instanceof ServerWorld sw)) return;
        if (!(target instanceof ServerPlayerEntity player)) return;

        phaseTimer++;
        if (tipCooldown > 0) tipCooldown--;

        // Смена фазы обучения
        if (phaseTimer >= PHASE_DURATION) {
            phaseTimer = 0;
            currentPhase = (currentPhase + 1) % 3;
            announcePhase(player);
        }

        // Защита игрока от смерти
        if (player.getHealth() < MIN_PLAYER_HP) {
            player.setHealth(MIN_PLAYER_HP);
        }

        // Советы по текущей фазе
        if (tipCooldown <= 0) {
            sendPhaseTip(player, bot, target);
            tipCooldown = TIP_INTERVAL;
        }

        // Анализ действий игрока (если он атакует бота)
        analyzePlayerAttacks(bot, player);
    }

    /** Проверить атаки игрока и дать обратную связь. */
    public void onPlayerHitBot(ServerPlayerEntity player, boolean isCrit, boolean isWTap) {
        if (!active) return;

        if (isCrit && isWTap) {
            tip(player, "§a✔ Отлично! Крит + W-Tap — идеальная атака!");
        } else if (isCrit) {
            tip(player, "§e✔ Хороший крит! Попробуй добавить W-Tap после удара.");
        } else if (isWTap) {
            tip(player, "§e✔ W-Tap сделан. Теперь добавь крит-прыжок перед ударом!");
        } else {
            tip(player, "§c✘ Обычный удар. Прыгни перед атакой (крит) + отпусти W после (W-Tap).");
        }
    }

    // ── Внутреннее ───────────────────────────────────────────────

    private void announcePhase(ServerPlayerEntity player) {
        String phase = switch (currentPhase) {
            case 0 -> "§e§l⚔ Фаза 1: КРИТЫ\n§7Прыгай перед каждым ударом — получишь х1.5 урон!";
            case 1 -> "§e§l⚔ Фаза 2: W-TAP\n§7Отпусти W сразу после удара — сбросишь кулдаун атаки!";
            case 2 -> "§e§l⚔ Фаза 3: СТРАФ\n§7Двигайся влево-вправо во время боя — сложнее попасть!";
            default -> "";
        };
        player.sendMessage(Text.literal("\n" + phase + "\n"), false);
    }

    private void sendPhaseTip(ServerPlayerEntity player, BotEntity bot, LivingEntity target) {
        String tip = switch (currentPhase) {
            case 0 -> "§7Подсказка: §fНажми §eПробел §fперед кликом мышью — это крит-прыжок!";
            case 1 -> "§7Подсказка: §fПосле удара §eотпусти W §fна 1-2 тика, затем снова зажми.";
            case 2 -> "§7Подсказка: §fЗажми §eA §fили §eD §fво время боя и меняй сторону каждые 1-2 сек.";
            default -> "";
        };
        if (!tip.isEmpty()) tip(player, tip);
    }

    private void analyzePlayerAttacks(BotEntity bot, ServerPlayerEntity player) {
        // Смотрим — игрок смотрит на бота? Даём тайминг-подсказку
        if (tipCooldown > TIP_INTERVAL - 5) return; // не слишком часто

        double attackCooldown = player.getAttackCooldownProgress(0.5f);
        if (attackCooldown < 0.5f && bot.distanceTo(player) < 4.0) {
            // Кулдаун ещё не готов — напомним
            // Только одна такая подсказка за фазу
        }
    }

    private static void tip(ServerPlayerEntity player, String msg) {
        player.sendMessage(Text.literal("§e[Тренер] §f" + msg), true); // actionbar
    }
}
