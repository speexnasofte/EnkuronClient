package com.pvpbot;

import java.util.*;

/**
 * KitStatsTracker — v14: Win/Loss таблица по режимам + Heatmap.
 *
 * Записывает:
 *   - Победы/поражения по каждому киту/режиму
 *   - Среднее HP при смерти (для heatmap урона)
 *   - Позиции смерти бота (для анализа опасных зон)
 */
public class KitStatsTracker {

    public static final KitStatsTracker INSTANCE = new KitStatsTracker();

    // ── Win/Loss по режимам ───────────────────────────────────────
    public static class KitRecord {
        public int wins   = 0;
        public int losses = 0;
        public float totalDamageDealt = 0;
        public float totalDamageTaken = 0;
        public int rounds = 0;

        public float winRate() {
            int total = wins + losses;
            return total > 0 ? (float) wins / total : 0f;
        }
        public float avgDamageDealt() {
            return rounds > 0 ? totalDamageDealt / rounds : 0f;
        }
    }

    // ── Heatmap — позиции смерти/высокого урона ───────────────────
    public static class HeatPoint {
        public final double x, y, z;
        public final float  hpAtDeath;
        public final String kit;

        public HeatPoint(double x, double y, double z, float hp, String kit) {
            this.x = x; this.y = y; this.z = z;
            this.hpAtDeath = hp;
            this.kit = kit;
        }
    }

    private final Map<String, KitRecord> kitRecords = new LinkedHashMap<>();
    private final List<HeatPoint>        heatPoints = new ArrayList<>();
    private static final int MAX_HEAT_POINTS = 50;

    // Текущий раунд
    private String currentKit    = "sword";
    private float  roundDamageDealt = 0;
    private float  roundDamageTaken = 0;

    private KitStatsTracker() {
        // Инициализируем записи для всех китов
        for (BotKit kit : BotKit.values()) {
            kitRecords.put(kit.id, new KitRecord());
        }
        // Новые режимы v14
        kitRecords.put("beehive",  new KitRecord());
        kitRecords.put("firework", new KitRecord());
        kitRecords.put("crossbow", new KitRecord());
    }

    /** Установить текущий кит (вызывается при /bot kit <name>). */
    public void setCurrentKit(String kitId) {
        currentKit = kitId;
        roundDamageDealt = 0;
        roundDamageTaken = 0;
    }

    /** Записать нанесённый урон в этом раунде. */
    public void recordDamageDealt(float dmg) {
        roundDamageDealt += dmg;
    }

    /** Записать полученный урон в этом раунде. */
    public void recordDamageTaken(float dmg) {
        roundDamageTaken += dmg;
    }

    /**
     * Зафиксировать победу (бот убил цель).
     */
    public void recordWin(net.minecraft.util.math.Vec3d botPos) {
        KitRecord rec = getOrCreate(currentKit);
        rec.wins++;
        rec.rounds++;
        rec.totalDamageDealt += roundDamageDealt;
        rec.totalDamageTaken += roundDamageTaken;
        roundDamageDealt = 0;
        roundDamageTaken = 0;
    }

    /**
     * Зафиксировать поражение (бот умер) + добавить точку на heatmap.
     */
    public void recordLoss(double x, double y, double z, float hpAtDeath) {
        KitRecord rec = getOrCreate(currentKit);
        rec.losses++;
        rec.rounds++;
        rec.totalDamageDealt += roundDamageDealt;
        rec.totalDamageTaken += roundDamageTaken;
        roundDamageDealt = 0;
        roundDamageTaken = 0;

        // Добавить в heatmap
        if (heatPoints.size() >= MAX_HEAT_POINTS) {
            heatPoints.remove(0);
        }
        heatPoints.add(new HeatPoint(x, y, z, hpAtDeath, currentKit));
    }

    /** Получить запись для кита. */
    public KitRecord getRecord(String kitId) {
        return kitRecords.getOrDefault(kitId, new KitRecord());
    }

    /** Получить все записи. */
    public Map<String, KitRecord> getAllRecords() {
        return Collections.unmodifiableMap(kitRecords);
    }

    /** Получить heatmap точки. */
    public List<HeatPoint> getHeatPoints() {
        return Collections.unmodifiableList(heatPoints);
    }

    /** Найти самый эффективный кит (по winRate). */
    public String getBestKit() {
        return kitRecords.entrySet().stream()
            .filter(e -> e.getValue().rounds > 0)
            .max(Comparator.comparingDouble(e -> e.getValue().winRate()))
            .map(Map.Entry::getKey)
            .orElse("нет данных");
    }

    /** Сброс всей статистики. */
    public void reset() {
        kitRecords.values().forEach(r -> {
            r.wins = r.losses = r.rounds = 0;
            r.totalDamageDealt = r.totalDamageTaken = 0;
        });
        heatPoints.clear();
    }

    private KitRecord getOrCreate(String id) {
        return kitRecords.computeIfAbsent(id, k -> new KitRecord());
    }

    /** Форматированная таблица для отображения в чат. */
    public String formatTable() {
        StringBuilder sb = new StringBuilder("§e§l📊 Win/Loss таблица по китам:\n");
        for (Map.Entry<String, KitRecord> e : kitRecords.entrySet()) {
            KitRecord r = e.getValue();
            if (r.rounds == 0) continue;
            String wr = String.format("%.0f%%", r.winRate() * 100);
            sb.append(String.format("§f%-10s §a%dW §c%dL §7(%s) §6avgDmg:%.0f\n",
                e.getKey(), r.wins, r.losses, wr, r.avgDamageDealt()));
        }
        sb.append("§7Лучший кит: §e").append(getBestKit());
        return sb.toString();
    }

    /** Форматированный heatmap (последние точки смерти). */
    public String formatHeatmap() {
        if (heatPoints.isEmpty()) return "§7Heatmap: §cнет данных";
        StringBuilder sb = new StringBuilder("§e§l🗺 Heatmap — точки смерти:\n");
        int max = Math.min(10, heatPoints.size());
        for (int i = heatPoints.size() - 1; i >= heatPoints.size() - max; i--) {
            HeatPoint p = heatPoints.get(i);
            sb.append(String.format("§7[%s] §fX:%.0f Y:%.0f Z:%.0f §cHP:%.1f\n",
                p.kit, p.x, p.y, p.z, p.hpAtDeath));
        }
        return sb.toString();
    }
}
