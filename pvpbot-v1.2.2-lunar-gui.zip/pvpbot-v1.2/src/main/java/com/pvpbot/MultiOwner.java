package com.pvpbot;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

import java.util.*;

/**
 * MultiOwner — v15: несколько игроков могут управлять ботами.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Как работает:
 * ══════════════════════════════════════════════════════════════════
 *
 *  - Боты принадлежат «основному владельцу» (ownerUUID в BotEntity).
 *  - Дополнительные совладельцы хранятся в MultiOwner.INSTANCE (Map по ботам).
 *  - Совладелец может:
 *      • отдавать команды всем ботам основного владельца
 *      • получать уведомления через BotNotifier
 *      • видеть /bot status
 *  - Совладелец НЕ может: добавлять/удалять других совладельцев.
 *
 *  Команды:
 *    /bot owner add <ник>       — добавить совладельца
 *    /bot owner remove <ник>    — убрать совладельца
 *    /bot owner list            — список совладельцев
 *
 *  GUI (вкладка OWNERS в PVPBotScreen):
 *    текстовое поле ника + кнопка Apply → вызывает addCoOwner(...)
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class MultiOwner {

    public static final MultiOwner INSTANCE = new MultiOwner();

    /**
     * UUID основного владельца → список UUID совладельцев.
     * Ключ — ownerUUID бота (= UUID спавнившего игрока).
     */
    private final Map<UUID, Set<UUID>> coOwners = new HashMap<>();

    /** UUID → ник (кэш для отображения) */
    private final Map<UUID, String> nickCache = new HashMap<>();

    // ══════════════════════════════════════════════════════════════
    //  Публичный API
    // ══════════════════════════════════════════════════════════════

    /**
     * Добавить совладельца по нику.
     * Нужен MinecraftServer для поиска игрока по нику.
     * @return true если игрок найден и добавлен
     */
    public boolean addCoOwner(UUID ownerUUID, String nick, MinecraftServer server) {
        ServerPlayerEntity target = server.getPlayerManager().getPlayer(nick);
        if (target == null) return false;

        UUID targetUUID = target.getUuid();
        if (targetUUID.equals(ownerUUID)) return false; // сам себя не добавляем

        coOwners.computeIfAbsent(ownerUUID, k -> new LinkedHashSet<>()).add(targetUUID);
        nickCache.put(targetUUID, nick);
        return true;
    }

    /**
     * Добавить совладельца по нику (GUI-версия: не нужен server, если игрок онлайн).
     * Ищет игрока через список ботов их сервера.
     */
    public boolean addCoOwnerByNick(UUID ownerUUID, String nick, MinecraftServer server) {
        return addCoOwner(ownerUUID, nick, server);
    }

    /** Удалить совладельца по нику */
    public boolean removeCoOwner(UUID ownerUUID, String nick) {
        Set<UUID> set = coOwners.get(ownerUUID);
        if (set == null) return false;
        UUID found = null;
        for (UUID uuid : set) {
            if (nick.equalsIgnoreCase(nickCache.get(uuid))) {
                found = uuid;
                break;
            }
        }
        if (found == null) return false;
        set.remove(found);
        nickCache.remove(found);
        return true;
    }

    /** Удалить совладельца по UUID */
    public boolean removeCoOwner(UUID ownerUUID, UUID coUUID) {
        Set<UUID> set = coOwners.get(ownerUUID);
        if (set == null) return false;
        nickCache.remove(coUUID);
        return set.remove(coUUID);
    }

    /** Получить список совладельцев (UUID) для данного владельца */
    public Set<UUID> getCoOwners(UUID ownerUUID) {
        return coOwners.getOrDefault(ownerUUID, Collections.emptySet());
    }

    /** Получить список ников совладельцев */
    public List<String> getCoOwnerNicks(UUID ownerUUID) {
        Set<UUID> set = coOwners.getOrDefault(ownerUUID, Collections.emptySet());
        List<String> result = new ArrayList<>();
        for (UUID uuid : set) {
            result.add(nickCache.getOrDefault(uuid, uuid.toString().substring(0, 8)));
        }
        return result;
    }

    /**
     * Проверить — может ли игрок управлять ботами данного владельца.
     * Сам владелец всегда может.
     */
    public boolean canControl(UUID ownerUUID, UUID playerUUID) {
        if (ownerUUID.equals(playerUUID)) return true;
        Set<UUID> set = coOwners.get(ownerUUID);
        return set != null && set.contains(playerUUID);
    }

    /** Очистить всех совладельцев данного владельца */
    public void clearCoOwners(UUID ownerUUID) {
        Set<UUID> set = coOwners.remove(ownerUUID);
        if (set != null) set.forEach(nickCache::remove);
    }

    /** Отправить сообщение всем совладельцам (для BotNotifier) */
    public void broadcastToCoOwners(UUID ownerUUID, String message, MinecraftServer server) {
        if (server == null) return;
        Set<UUID> set = coOwners.getOrDefault(ownerUUID, Collections.emptySet());
        for (UUID uuid : set) {
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(uuid);
            if (player != null) {
                player.sendMessage(Text.literal(message), false);
            }
        }
    }

    // ── Ник по UUID (из кэша) ────────────────────────────────────
    public String getNick(UUID uuid) {
        return nickCache.getOrDefault(uuid, uuid.toString().substring(0, 8) + "...");
    }
}
