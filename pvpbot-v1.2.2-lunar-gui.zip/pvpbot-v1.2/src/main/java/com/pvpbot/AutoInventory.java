package com.pvpbot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public class AutoInventory {

    private final PVPBotConfig cfg = PVPBotConfig.INSTANCE;
    private int checkTimer = 0;

    // Минимальное количество предметов
    private static final int CRYSTALS_MIN = 16;
    private static final int TOTEMS_MIN   = 2;
    private static final int FOOD_MIN     = 8;

    public void tick(MinecraftClient mc) {
        if (mc.player == null || !cfg.autoRefill) return;
        checkTimer--;
        if (checkTimer > 0) return;
        checkTimer = 60; // проверка раз в 3 секунды

        PlayerEntity player = mc.player;

        if (cfg.refillCrystals && cfg.mode == PVPBotConfig.Mode.CRYSTAL) {
            refill(mc, Items.END_CRYSTAL, CRYSTALS_MIN);
        }
        if (cfg.refillTotems) {
            refill(mc, Items.TOTEM_OF_UNDYING, TOTEMS_MIN);
        }
        if (cfg.refillFood) {
            refill(mc, Items.GOLDEN_APPLE, FOOD_MIN);
        }
    }

    private void refill(MinecraftClient mc, Item item, int min) {
        if (mc.player == null) return;
        int current = countItem(mc.player, item);
        if (current >= min) return;

        int need = min - current;
        String id = Registries.ITEM.getId(item).toString();
        // Использует /give — работает только с OP или в одиночной игре с читами
        mc.player.networkHandler.sendChatCommand("give @s " + id + " " + need);
    }

    private int countItem(PlayerEntity player, Item item) {
        int count = 0;
        for (int i = 0; i < player.getInventory().size(); i++) {
            var stack = player.getInventory().getStack(i);
            if (stack.isOf(item)) count += stack.getCount();
        }
        return count;
    }
}
