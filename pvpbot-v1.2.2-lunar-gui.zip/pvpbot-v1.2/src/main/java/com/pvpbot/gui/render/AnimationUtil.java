package com.pvpbot.gui.render;

import java.util.HashMap;
import java.util.Map;

/**
 * AnimationUtil — хранит float-значения анимации для каждого элемента по ключу.
 * Использование:
 *   float anim = AnimationUtil.get("card_autoAttack");
 *   AnimationUtil.tick("card_autoAttack", isHovered ? 1f : 0f, 0.14f);
 */
public class AnimationUtil {

    private static final Map<String, Float> values = new HashMap<>();

    /** Получить текущее значение (0.0 – 1.0). */
    public static float get(String key) {
        return values.getOrDefault(key, 0f);
    }

    /**
     * Плавно двигать значение к target со скоростью speed.
     * Вызывать каждый кадр (в render()).
     * @return новое значение после тика
     */
    public static float tick(String key, float target, float speed) {
        float cur = values.getOrDefault(key, 0f);
        cur += (target - cur) * speed;
        if (Math.abs(target - cur) < 0.002f) cur = target;
        values.put(key, cur);
        return cur;
    }

    /** Сбросить все анимации (при закрытии экрана). */
    public static void clear() {
        values.clear();
    }

    /** Линейная интерполяция двух ARGB цветов. */
    public static int lerpColor(int from, int to, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int fa = (from >> 24) & 0xFF, fr = (from >> 16) & 0xFF,
            fg = (from >> 8) & 0xFF,  fb = from & 0xFF;
        int ta = (to   >> 24) & 0xFF, tr = (to   >> 16) & 0xFF,
            tg = (to   >> 8) & 0xFF,  tb = to   & 0xFF;
        int a = (int)(fa + (ta - fa) * t);
        int r = (int)(fr + (tr - fr) * t);
        int g = (int)(fg + (tg - fg) * t);
        int b = (int)(fb + (tb - fb) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
