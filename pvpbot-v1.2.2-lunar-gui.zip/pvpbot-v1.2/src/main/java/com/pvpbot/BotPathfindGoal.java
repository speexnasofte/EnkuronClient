package com.pvpbot;

import net.minecraft.block.BlockState;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.pathing.EntityNavigation;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.*;

/**
 * BotPathfindGoal — улучшенный pathfinding с прыжками через блоки.
 *
 * Проблема стандартного MC pathfinding:
 *   NavigationMob использует базовый PathNodeMaker, который не всегда
 *   прыгает через 1-блочные препятствия и застревает.
 *
 * Наш подход:
 *   1. Используем встроенный Navigation (он уже умеет в стены и прыжки)
 *   2. Добавляем систему "unstuck": если бот не движется 2 сек — телепортируем
 *   3. При достижении владельца (< 4 блока) — останавливаем
 *   4. Jump-assist: если впереди блок высотой 1 — принудительно прыгаем
 */
public class BotPathfindGoal extends Goal {

    private final BotEntity bot;
    private final double speed;
    private final float maxDist;
    private final float minDist;

    private PlayerEntity owner;

    // Unstuck система
    private Vec3d lastPos         = null;
    private int   stuckTimer      = 0;
    private static final int STUCK_THRESHOLD = 40; // 2 сек без движения

    // Прыжки через препятствия
    private int jumpCooldown = 0;

    public BotPathfindGoal(BotEntity bot, double speed, float maxDist, float minDist) {
        this.bot     = bot;
        this.speed   = speed;
        this.maxDist = maxDist;
        this.minDist = minDist;
        this.setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        if (bot.getTarget() != null) return false;
        owner = bot.getOwner();
        if (owner == null) return false;
        return owner.squaredDistanceTo(bot) > (minDist * minDist);
    }

    @Override
    public boolean shouldContinue() {
        if (bot.getTarget() != null) return false;
        if (owner == null) return false;
        double d = owner.squaredDistanceTo(bot);
        return d > (minDist * minDist) && d < (maxDist * maxDist * 16);
    }

    @Override
    public void start() {
        stuckTimer = 0;
        lastPos    = bot.getPos();
        navigate();
    }

    @Override
    public void stop() {
        bot.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (owner == null) return;

        bot.getLookControl().lookAt(owner, 10f, bot.getMaxLookPitchChange());

        jumpCooldown--;

        // Обновляем путь каждые 10 тиков
        if (bot.age % 10 == 0) {
            navigate();
        }

        // Jump-assist: проверяем блок впереди
        if (jumpCooldown <= 0 && bot.isOnGround()) {
            checkAndJump();
        }

        // Unstuck: если не двигаемся — принудительно телепортируем или прыгаем
        Vec3d curr = bot.getPos();
        if (lastPos != null) {
            double moved = curr.squaredDistanceTo(lastPos);
            if (moved < 0.01) {
                stuckTimer++;
                if (stuckTimer > STUCK_THRESHOLD) {
                    unstuck();
                    stuckTimer = 0;
                }
            } else {
                stuckTimer = 0;
            }
        }
        lastPos = curr;
    }

    private void navigate() {
        if (owner == null) return;
        double dist = bot.distanceTo(owner);

        // Formations v10/v11: используем смещённую целевую позицию
        Vec3d target = BotFormations.INSTANCE.getTargetPos(bot, 0, 1, owner);

        if (dist > 48.0) {
            // Телепорт если очень далеко
            bot.teleport(target.x, target.y, target.z);
        } else {
            bot.getNavigation().startMovingTo(target.x, target.y, target.z, speed);
        }
    }

    /**
     * Проверяем есть ли блок высотой 1 впереди — если да, прыгаем.
     * "Впереди" = 1.5 блока по направлению движения.
     */
    private void checkAndJump() {
        Vec3d vel = bot.getVelocity();
        if (vel.horizontalLengthSquared() < 0.01) return; // не движемся

        Vec3d dir = new Vec3d(vel.x, 0, vel.z).normalize();
        World world = bot.getWorld();

        // Позиция на 1 блок вперёд у ног
        BlockPos ahead = BlockPos.ofFloored(
            bot.getX() + dir.x * 1.0,
            bot.getY(),
            bot.getZ() + dir.z * 1.0
        );

        // Если блок впереди на уровне ног — прыгаем
        BlockState stateAhead = world.getBlockState(ahead);
        BlockState stateAbove = world.getBlockState(ahead.up());

        if (!stateAhead.isAir() && stateAbove.isAir()) {
            // Блок высотой ≤ 1, над ним свободно — прыгаем
            bot.setVelocity(bot.getVelocity().x, 0.42, bot.getVelocity().z);
            bot.velocityModified = true;
            jumpCooldown = 10;
        }
    }

    /**
     * Unstuck: пробуем выпрыгнуть или телепортируемся к владельцу.
     */
    private void unstuck() {
        if (owner == null) return;
        double dist = bot.distanceTo(owner);

        if (dist < 20.0) {
            // Попытка прыжка
            bot.setVelocity(
                (owner.getX() - bot.getX()) * 0.2,
                0.5,
                (owner.getZ() - bot.getZ()) * 0.2
            );
            bot.velocityModified = true;
        } else {
            // Телепорт к владельцу
            bot.teleport(owner.getX(), owner.getY(), owner.getZ());
        }

        navigate();
    }
}
