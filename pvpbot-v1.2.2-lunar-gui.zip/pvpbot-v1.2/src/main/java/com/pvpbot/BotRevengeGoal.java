package com.pvpbot;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.RevengeGoal;

/**
 * Бот мстит тому, кто атаковал его или его владельца.
 */
public class BotRevengeGoal extends RevengeGoal {

    private final BotEntity bot;

    public BotRevengeGoal(BotEntity bot) {
        super(bot);
        this.bot = bot;
    }

    @Override
    public boolean canStart() {
        if (bot.getBotMode() == BotEntity.BotMode.PASSIVE) return false;
        // Реагируем на атаку по нам
        if (super.canStart()) return true;
        // Реагируем на атаку по владельцу
        var owner = bot.getOwner();
        if (owner != null) {
            LivingEntity ownerAttacker = owner.getAttacker();
            if (ownerAttacker != null && ownerAttacker != bot) {
                bot.setTarget(ownerAttacker);
                return true;
            }
        }
        return false;
    }
}
