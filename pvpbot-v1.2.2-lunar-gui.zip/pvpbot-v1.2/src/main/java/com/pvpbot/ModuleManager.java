package com.pvpbot;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * ModuleManager — система гибких настроек модулей v8.
 *
 * Каждый модуль имеет:
 *   - enabled (вкл/выкл)
 *   - priority (порядок исполнения)
 *   - настраиваемые параметры (Map<String, Object>)
 *
 * Профили сохраняются в .minecraft/config/pvpbot-profiles/<name>.json
 * Переключение: /bot profile <name>
 *
 * Встроенные профили: pvp, pve, crystal, passive
 */
public class ModuleManager {

    public static final ModuleManager INSTANCE = new ModuleManager();

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PROFILES_DIR =
        FabricLoader.getInstance().getConfigDir().resolve("pvpbot-profiles");

    // Текущий активный профиль
    private String activeProfile = "default";

    // Реестр модулей: имя → состояние
    private final Map<String, ModuleState> modules = new LinkedHashMap<>();

    // ── Определение модулей ──────────────────────────────────────

    public static final String MOD_AUTO_ATTACK  = "auto_attack";
    public static final String MOD_AUTO_DODGE   = "auto_dodge";
    public static final String MOD_AUTO_HEAL    = "auto_heal";
    public static final String MOD_AUTO_EAT     = "auto_eat";
    public static final String MOD_AUTO_GAP     = "auto_gap";
    public static final String MOD_AUTO_SPRINT  = "auto_sprint";
    public static final String MOD_AUTO_TOTEM   = "auto_totem";
    public static final String MOD_AUTO_ARMOR   = "auto_armor";
    public static final String MOD_AUTO_BOW     = "auto_bow";
    public static final String MOD_KITE         = "kite";
    public static final String MOD_W_TAP        = "w_tap";
    public static final String MOD_S_TAP        = "s_tap";
    public static final String MOD_ESP          = "esp";
    public static final String MOD_RADAR        = "radar";
    public static final String MOD_CRYSTAL      = "auto_crystal";
    public static final String MOD_STATS        = "stats";
    public static final String MOD_HUD          = "hud";

    // v10
    public static final String MOD_AUTO_BLOCK      = "auto_block";
    public static final String MOD_ANTI_KNOCKBACK  = "anti_knockback";

    // v11
    public static final String MOD_AUTO_LOG        = "auto_log";
    public static final String MOD_AUTO_PEARL      = "auto_pearl";
    public static final String MOD_TRACERS         = "tracers";

    // ── Класс состояния модуля ───────────────────────────────────

    public static class ModuleState {
        public boolean enabled;
        public int     priority;          // меньше = выше приоритет
        public Map<String, Object> params = new LinkedHashMap<>();

        public ModuleState(boolean enabled, int priority) {
            this.enabled  = enabled;
            this.priority = priority;
        }

        public boolean getBool(String key, boolean def) {
            Object v = params.get(key);
            return v instanceof Boolean ? (Boolean) v : def;
        }

        public double getDouble(String key, double def) {
            Object v = params.get(key);
            if (v instanceof Number) return ((Number) v).doubleValue();
            return def;
        }

        public int getInt(String key, int def) {
            Object v = params.get(key);
            if (v instanceof Number) return ((Number) v).intValue();
            return def;
        }

        public void set(String key, Object value) {
            params.put(key, value);
        }
    }

    // ── Инициализация ────────────────────────────────────────────

    private ModuleManager() {
        registerDefaults();
    }

    private void registerDefaults() {
        register(MOD_AUTO_ATTACK,  true,  10);
        register(MOD_AUTO_DODGE,   true,  20);
        register(MOD_AUTO_HEAL,    true,  5);
        register(MOD_AUTO_EAT,     true,  6);
        register(MOD_AUTO_GAP,     true,  4);   // высокий приоритет — лечение прежде всего
        register(MOD_AUTO_SPRINT,  true,  30);
        register(MOD_AUTO_TOTEM,   true,  1);   // наивысший
        register(MOD_AUTO_ARMOR,   true,  2);
        register(MOD_AUTO_BOW,     false, 15);
        register(MOD_KITE,         false, 12);
        register(MOD_W_TAP,        true,  11);
        register(MOD_S_TAP,        false, 11);
        register(MOD_ESP,          true,  50);
        register(MOD_RADAR,        true,  50);
        register(MOD_CRYSTAL,      false, 10);
        register(MOD_STATS,        true,  60);
        register(MOD_HUD,          true,  60);
        // v10
        register(MOD_AUTO_BLOCK,     true,  3);   // высокий приоритет — блок прежде атаки
        ModuleState kbState = register(MOD_ANTI_KNOCKBACK, true, 2);
        kbState.set("resistance", 0.8); // 80% подавления кнокбэка по умолчанию

        // v11
        ModuleState logState = register(MOD_AUTO_LOG, false, 1); // выключен по умолчанию — безопасно
        logState.set("hp_threshold", 6.0);
        logState.set("cooldown_ticks", 20);

        ModuleState pearlState = register(MOD_AUTO_PEARL, false, 13);
        pearlState.set("mode", "gap_close");
        pearlState.set("gap_threshold", 8.0);
        pearlState.set("hp_min", 12.0);
        pearlState.set("escape_hp", 8.0);
        pearlState.set("cooldown", 60);

        ModuleState tracersState = register(MOD_TRACERS, false, 51);
        tracersState.set("range", 64.0);
        tracersState.set("players_only", false);
    }

    private ModuleState register(String name, boolean defaultEnabled, int priority) {
        ModuleState state = new ModuleState(defaultEnabled, priority);
        modules.put(name, state);
        return state;
    }

    // ── API ──────────────────────────────────────────────────────

    public boolean isEnabled(String module) {
        ModuleState s = modules.get(module);
        return s != null && s.enabled;
    }

    public void setEnabled(String module, boolean enabled) {
        ModuleState s = modules.get(module);
        if (s != null) s.enabled = enabled;
    }

    public void toggle(String module) {
        ModuleState s = modules.get(module);
        if (s != null) s.enabled = !s.enabled;
    }

    public ModuleState get(String module) {
        return modules.get(module);
    }

    /** Алиас для get() — для читаемости в AntiKnockback и др. */
    public ModuleState getModule(String module) {
        return get(module);
    }

    public Set<String> getModuleNames() {
        return modules.keySet();
    }

    public String getActiveProfile() { return activeProfile; }

    // ── Синхронизация с PVPBotConfig ─────────────────────────────

    /**
     * Применяет состояния модулей в PVPBotConfig.
     * Вызывать после load() или переключения профиля.
     */
    public void applyToConfig() {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        cfg.autoAttack    = isEnabled(MOD_AUTO_ATTACK);
        cfg.autoDodge     = isEnabled(MOD_AUTO_DODGE);
        cfg.autoHeal      = isEnabled(MOD_AUTO_HEAL);
        cfg.autoEat       = isEnabled(MOD_AUTO_EAT);
        cfg.autoGapEnabled = isEnabled(MOD_AUTO_GAP);
        cfg.autoSprint    = isEnabled(MOD_AUTO_SPRINT);
        cfg.autoTotem     = isEnabled(MOD_AUTO_TOTEM);
        cfg.autoArmor     = isEnabled(MOD_AUTO_ARMOR);
        cfg.autoBowEnabled = isEnabled(MOD_AUTO_BOW);
        cfg.kiteEnabled   = isEnabled(MOD_KITE);
        cfg.wTapEnabled   = isEnabled(MOD_W_TAP);
        cfg.sTapEnabled   = isEnabled(MOD_S_TAP);
        cfg.espEnabled    = isEnabled(MOD_ESP);
        cfg.radarEnabled  = isEnabled(MOD_RADAR);
        cfg.autoCrystal   = isEnabled(MOD_CRYSTAL);
        cfg.statsEnabled  = isEnabled(MOD_STATS);
        cfg.showHud       = isEnabled(MOD_HUD);

        // v11
        ModuleState autoLog = get(MOD_AUTO_LOG);
        if (autoLog != null) {
            cfg.autoLogEnabled    = autoLog.enabled;
            cfg.autoLogHpThreshold = (float) autoLog.getDouble("hp_threshold", 6.0);
        }
        ModuleState pearl = get(MOD_AUTO_PEARL);
        if (pearl != null) {
            cfg.autoPearlEnabled = pearl.enabled;
        }
        ModuleState tracers = get(MOD_TRACERS);
        if (tracers != null) {
            cfg.tracersEnabled = tracers.enabled;
        }

        // Параметры с кастомными значениями из модуля
        ModuleState gap = get(MOD_AUTO_GAP);
        if (gap != null) {
            cfg.autoGapHpThreshold = (float) gap.getDouble("hp_threshold", 10.0);
        }

        ModuleState wtap = get(MOD_W_TAP);
        if (wtap != null) {
            cfg.wTapReleaseTicks = wtap.getInt("release_ticks", 2);
        }
    }

    // ── Профили ──────────────────────────────────────────────────

    public void saveProfile(String name) {
        try {
            Files.createDirectories(PROFILES_DIR);
            Path file = PROFILES_DIR.resolve(name + ".json");
            try (Writer w = Files.newBufferedWriter(file)) {
                GSON.toJson(modules, w);
            }
        } catch (IOException e) {
            System.err.println("[PVPBot] Не удалось сохранить профиль '" + name + "': " + e.getMessage());
        }
    }

    public boolean loadProfile(String name) {
        Path file = PROFILES_DIR.resolve(name + ".json");
        if (!Files.exists(file)) {
            // Пробуем встроенный профиль
            return loadBuiltinProfile(name);
        }
        try (Reader r = Files.newBufferedReader(file)) {
            Type type = new TypeToken<Map<String, ModuleState>>(){}.getType();
            Map<String, ModuleState> loaded = GSON.fromJson(r, type);
            if (loaded != null) {
                loaded.forEach((k, v) -> {
                    if (modules.containsKey(k)) modules.put(k, v);
                });
            }
            activeProfile = name;
            applyToConfig();
            return true;
        } catch (IOException e) {
            System.err.println("[PVPBot] Не удалось загрузить профиль '" + name + "': " + e.getMessage());
            return false;
        }
    }

    /**
     * Встроенные профили: pvp, pve, crystal, passive
     */
    private boolean loadBuiltinProfile(String name) {
        switch (name.toLowerCase()) {
            case "pvp" -> {
                setAll(true);
                setEnabled(MOD_CRYSTAL, false);
                setEnabled(MOD_KITE, false);
                PVPBotConfig.INSTANCE.difficulty = PVPBotConfig.Difficulty.HARD;
                PVPBotConfig.INSTANCE.mode = PVPBotConfig.Mode.SWORD;
            }
            case "crystal" -> {
                setAll(true);
                setEnabled(MOD_CRYSTAL, true);
                setEnabled(MOD_W_TAP, false);
                PVPBotConfig.INSTANCE.difficulty = PVPBotConfig.Difficulty.EXPERT;
                PVPBotConfig.INSTANCE.mode = PVPBotConfig.Mode.CRYSTAL;
            }
            case "pve" -> {
                setAll(true);
                setEnabled(MOD_AUTO_BOW, true);
                setEnabled(MOD_KITE, true);
                setEnabled(MOD_W_TAP, false);
                PVPBotConfig.INSTANCE.difficulty = PVPBotConfig.Difficulty.MEDIUM;
                PVPBotConfig.INSTANCE.mode = PVPBotConfig.Mode.SWORD;
            }
            case "passive" -> {
                setAll(false);
                setEnabled(MOD_AUTO_TOTEM, true);
                setEnabled(MOD_AUTO_ARMOR, true);
                setEnabled(MOD_AUTO_EAT, true);
                setEnabled(MOD_HUD, true);
                setEnabled(MOD_STATS, true);
            }

            // ── Новые киты v12 ────────────────────────────────────
            case "smp" -> {
                setAll(true);
                setEnabled(MOD_CRYSTAL,    false);
                setEnabled(MOD_AUTO_BOW,   false);
                setEnabled(MOD_KITE,       false);
                setEnabled(MOD_W_TAP,      true);
                setEnabled(MOD_AUTO_EAT,   true);
                setEnabled(MOD_AUTO_ARMOR, true);
                PVPBotConfig.INSTANCE.difficulty = PVPBotConfig.Difficulty.MEDIUM;
                PVPBotConfig.INSTANCE.mode = PVPBotConfig.Mode.SMP;
            }
            case "uhc" -> {
                setAll(true);
                setEnabled(MOD_CRYSTAL,    false);
                setEnabled(MOD_AUTO_BOW,   true);
                setEnabled(MOD_KITE,       true);
                setEnabled(MOD_AUTO_HEAL,  false);
                setEnabled(MOD_AUTO_GAP,   true);
                setEnabled(MOD_W_TAP,      true);
                PVPBotConfig.INSTANCE.difficulty = PVPBotConfig.Difficulty.HARD;
                PVPBotConfig.INSTANCE.mode = PVPBotConfig.Mode.UHC;
            }
            case "nethpot" -> {
                setAll(true);
                setEnabled(MOD_CRYSTAL,    false);
                setEnabled(MOD_AUTO_BOW,   false);
                setEnabled(MOD_KITE,       false);
                setEnabled(MOD_W_TAP,      true);
                setEnabled(MOD_S_TAP,      true);
                setEnabled(MOD_AUTO_HEAL,  true);
                setEnabled(MOD_AUTO_GAP,   false);
                PVPBotConfig.INSTANCE.difficulty = PVPBotConfig.Difficulty.HARD;
                PVPBotConfig.INSTANCE.mode = PVPBotConfig.Mode.NETHPOT;
            }
            case "axe" -> {
                setAll(true);
                setEnabled(MOD_CRYSTAL,    false);
                setEnabled(MOD_AUTO_BOW,   false);
                setEnabled(MOD_KITE,       false);
                setEnabled(MOD_W_TAP,      false);
                setEnabled(MOD_S_TAP,      false);
                setEnabled(MOD_AUTO_TOTEM, true);
                setEnabled(MOD_AUTO_ARMOR, true);
                PVPBotConfig.INSTANCE.difficulty = PVPBotConfig.Difficulty.HARD;
                PVPBotConfig.INSTANCE.mode = PVPBotConfig.Mode.AXE;
            }
            case "tpc" -> {
                setAll(true);
                setEnabled(MOD_CRYSTAL,    true);
                setEnabled(MOD_AUTO_BOW,   false);
                setEnabled(MOD_KITE,       true);
                setEnabled(MOD_W_TAP,      false);
                setEnabled(MOD_AUTO_TOTEM, true);
                setEnabled(MOD_AUTO_GAP,   true);
                PVPBotConfig.INSTANCE.difficulty = PVPBotConfig.Difficulty.EXPERT;
                PVPBotConfig.INSTANCE.mode = PVPBotConfig.Mode.TPC;
            }

            default -> { return false; }
        }
        activeProfile = name;
        applyToConfig();
        PVPBotConfig.INSTANCE.applyDifficulty();
        return true;
    }

    public List<String> listProfiles() {
        List<String> list = new ArrayList<>(Arrays.asList("pvp", "pve", "crystal", "passive", "smp", "uhc", "nethpot", "axe", "tpc"));
        try {
            if (Files.exists(PROFILES_DIR)) {
                Files.list(PROFILES_DIR)
                    .filter(p -> p.toString().endsWith(".json"))
                    .forEach(p -> {
                        String n = p.getFileName().toString().replace(".json", "");
                        if (!list.contains(n)) list.add(n);
                    });
            }
        } catch (IOException ignored) {}
        return list;
    }

    private void setAll(boolean enabled) {
        modules.values().forEach(s -> s.enabled = enabled);
    }
}
