package com.pvpbot;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Executors;

/**
 * WebConfig — v15: HTTP-сервер для настройки бота через браузер.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Запуск / остановка:
 * ══════════════════════════════════════════════════════════════════
 *   WebConfig.INSTANCE.start(port);   // обычно port=7420
 *   WebConfig.INSTANCE.stop();
 *
 *  Открыть в браузере: http://localhost:7420
 *
 * ══════════════════════════════════════════════════════════════════
 *  Маршруты:
 * ══════════════════════════════════════════════════════════════════
 *   GET  /          — HTML-страница с формой (текущие настройки)
 *   POST /apply     — принимает form-данные, обновляет PVPBotConfig
 *   GET  /status    — JSON: режим, HP ботов, кол-во ботов
 *
 * ══════════════════════════════════════════════════════════════════
 *  Безопасность:
 * ══════════════════════════════════════════════════════════════════
 *   Сервер слушает только localhost (127.0.0.1) — не доступен
 *   из сети, только с локальной машины.
 * ══════════════════════════════════════════════════════════════════
 */
public class WebConfig {

    public static final WebConfig INSTANCE = new WebConfig();

    private HttpServer server = null;
    private int        port   = 7420;
    private boolean    running = false;

    // ══════════════════════════════════════════════════════════════
    //  Запуск / остановка
    // ══════════════════════════════════════════════════════════════

    public boolean start(int port) {
        if (running) stop();
        this.port = port;
        try {
            server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
            server.createContext("/",       this::handleRoot);
            server.createContext("/apply",  this::handleApply);
            server.createContext("/status", this::handleStatus);
            server.setExecutor(Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "pvpbot-webconfig");
                t.setDaemon(true);
                return t;
            }));
            server.start();
            running = true;
            System.out.println("[PVPBot] WebConfig запущен: http://localhost:" + port);
            return true;
        } catch (Exception e) {
            System.err.println("[PVPBot] WebConfig ошибка старта: " + e.getMessage());
            return false;
        }
    }

    public void stop() {
        if (server != null) {
            server.stop(0);
            server = null;
        }
        running = false;
        System.out.println("[PVPBot] WebConfig остановлен.");
    }

    public boolean isRunning() { return running; }
    public int     getPort()   { return port; }

    // ══════════════════════════════════════════════════════════════
    //  GET / — HTML-страница с формой
    // ══════════════════════════════════════════════════════════════

    private void handleRoot(HttpExchange ex) throws IOException {
        if (!"GET".equals(ex.getRequestMethod())) { send(ex, 405, "text/plain", "Method Not Allowed"); return; }
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;

        String html = "<!DOCTYPE html><html lang='ru'><head>" +
            "<meta charset='UTF-8'>" +
            "<title>PVPBot Config</title>" +
            "<style>" +
            "body{font-family:monospace;background:#0f0f13;color:#ccc;margin:0;padding:20px}" +
            "h1{color:#4ea8de;margin:0 0 4px}" +
            ".sub{color:#555;font-size:12px;margin-bottom:20px}" +
            "form{max-width:560px}" +
            ".section{background:#16161e;border:1px solid #1e1e28;border-radius:8px;padding:16px;margin-bottom:14px}" +
            ".section h3{color:#7aa2f7;margin:0 0 12px;font-size:13px;text-transform:uppercase;letter-spacing:1px}" +
            ".row{display:flex;align-items:center;margin-bottom:10px;gap:10px}" +
            "label{flex:1;font-size:13px;color:#aaa}" +
            "select,input[type=text],input[type=number]{background:#0d0d12;border:1px solid #2a2a38;color:#e0e0e0;" +
            "padding:5px 8px;border-radius:5px;font-family:monospace;font-size:13px;width:160px}" +
            "input[type=checkbox]{accent-color:#4ea8de;width:16px;height:16px}" +
            ".btn{background:#4ea8de;color:#0f0f13;border:none;padding:10px 28px;border-radius:6px;" +
            "font-family:monospace;font-size:14px;font-weight:bold;cursor:pointer;letter-spacing:1px}" +
            ".btn:hover{background:#62c3f8}" +
            ".ok{color:#9ece6a;margin-left:12px;font-size:13px}" +
            "</style></head><body>" +
            "<h1>⚔ PVPBot WebConfig</h1>" +
            "<div class='sub'>http://localhost:" + port + " &nbsp;·&nbsp; только localhost</div>" +
            "<form method='POST' action='/apply'>" +

            "<div class='section'><h3>Режим и сложность</h3>" +
            selRow("mode", "Режим", cfg.mode.name(),
                modesOptions(cfg.mode.name())) +
            selRow("difficulty", "Сложность", cfg.difficulty.name(),
                "<option>EASY</option><option>MEDIUM</option><option>HARD</option><option>EXPERT</option>") +
            "</div>" +

            "<div class='section'><h3>Боевые параметры</h3>" +
            numRow("attackRange",    "Attack Range",          cfg.attackRange,    1.0, 10.0, 0.5) +
            numRow("attackCooldown", "Attack Cooldown (tick)", cfg.attackCooldown, 1,   30,   1) +
            numRow("dodgeRange",     "Dodge Range",            cfg.dodgeRange,     1.0, 8.0,  0.5) +
            checkRow("autoAttack",  "Auto Attack",  cfg.autoAttack) +
            checkRow("autoDodge",   "Auto Dodge",   cfg.autoDodge) +
            checkRow("wTapEnabled", "W-Tap",        cfg.wTapEnabled) +
            checkRow("sTapEnabled", "S-Tap",        cfg.sTapEnabled) +
            "</div>" +

            "<div class='section'><h3>Выживание</h3>" +
            numRow("healThreshold",    "Heal HP ≤",          cfg.healThreshold,    1.0, 20.0, 1.0) +
            numRow("autoGapHpThreshold","Gap HP ≤",          cfg.autoGapHpThreshold,1.0, 20.0, 1.0) +
            checkRow("autoHeal",   "Auto Heal",   cfg.autoHeal) +
            checkRow("autoEat",    "Auto Eat",    cfg.autoEat) +
            checkRow("autoTotem",  "Auto Totem",  cfg.autoTotem) +
            checkRow("autoArmor",  "Auto Armor",  cfg.autoArmor) +
            checkRow("autoRespawn","Auto Respawn",cfg.autoRespawn) +
            "</div>" +

            "<div class='section'><h3>Уведомления и AI</h3>" +
            checkRow("notificationsEnabled", "Chat Notifications", cfg.notificationsEnabled) +
            checkRow("patternAIEnabled",     "Pattern AI",         cfg.patternAIEnabled) +
            checkRow("antiPatternEnabled",   "Anti-Pattern",       cfg.antiPatternEnabled) +
            checkRow("trainingMode",         "Training Mode",      cfg.trainingMode) +
            checkRow("autoKitSelect",        "Auto Kit Select",    cfg.autoKitSelect) +
            "</div>" +

            "<div class='section'><h3>Multi-Owner</h3>" +
            "<div class='row'><label>Совладельцы:</label>" +
            "<span style='color:#7aa2f7;font-size:12px'>" + coOwnerList() + "</span></div>" +
            "<div class='row'><label>Добавить ник:</label>" +
            "<input type='text' name='addCoOwner' placeholder='ник игрока' style='width:160px'></div>" +
            "<div class='row'><label>Удалить ник:</label>" +
            "<input type='text' name='removeCoOwner' placeholder='ник игрока' style='width:160px'></div>" +
            "</div>" +

            "<div class='section'><h3>Бункер (Bunker Mode)</h3>" +
            checkRow("bunkerEnabled",   "Bunker Mode",       PVPBotConfig.INSTANCE.bunkerEnabled) +
            numRow("bunkerHpThreshold","Активация HP ≤", PVPBotConfig.INSTANCE.bunkerHpThreshold, 1.0, 40.0, 1.0) +
            "</div>" +

            "<div style='margin-top:16px'>" +
            "<button class='btn' type='submit'>✔ APPLY</button>" +
            "</div>" +
            "</form></body></html>";

        send(ex, 200, "text/html; charset=UTF-8", html);
    }

    // ══════════════════════════════════════════════════════════════
    //  POST /apply — применить настройки
    // ══════════════════════════════════════════════════════════════

    private void handleApply(HttpExchange ex) throws IOException {
        if (!"POST".equals(ex.getRequestMethod())) { send(ex, 405, "text/plain", "Method Not Allowed"); return; }

        String body = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
        var params  = parseForm(body);
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;

        // Mode
        try { cfg.mode       = PVPBotConfig.Mode.valueOf(params.getOrDefault("mode", cfg.mode.name())); } catch (Exception ignored) {}
        // Difficulty
        try { cfg.difficulty = PVPBotConfig.Difficulty.valueOf(params.getOrDefault("difficulty", cfg.difficulty.name()));
              cfg.applyDifficulty(); } catch (Exception ignored) {}

        // Числовые
        cfg.attackRange         = parseDouble(params.get("attackRange"),         cfg.attackRange);
        cfg.attackCooldown      = parseInt(   params.get("attackCooldown"),       cfg.attackCooldown);
        cfg.dodgeRange          = parseDouble(params.get("dodgeRange"),           cfg.dodgeRange);
        cfg.healThreshold       = (float) parseDouble(params.get("healThreshold"),cfg.healThreshold);
        cfg.autoGapHpThreshold  = (float) parseDouble(params.get("autoGapHpThreshold"), cfg.autoGapHpThreshold);
        cfg.bunkerHpThreshold   = (float) parseDouble(params.get("bunkerHpThreshold"),  cfg.bunkerHpThreshold);

        // Булевые (чекбоксы — присутствуют в форме если checked, иначе нет)
        cfg.autoAttack             = params.containsKey("autoAttack");
        cfg.autoDodge              = params.containsKey("autoDodge");
        cfg.wTapEnabled            = params.containsKey("wTapEnabled");
        cfg.sTapEnabled            = params.containsKey("sTapEnabled");
        cfg.autoHeal               = params.containsKey("autoHeal");
        cfg.autoEat                = params.containsKey("autoEat");
        cfg.autoTotem              = params.containsKey("autoTotem");
        cfg.autoArmor              = params.containsKey("autoArmor");
        cfg.autoRespawn            = params.containsKey("autoRespawn");
        cfg.notificationsEnabled   = params.containsKey("notificationsEnabled");
        cfg.patternAIEnabled       = params.containsKey("patternAIEnabled");
        cfg.antiPatternEnabled     = params.containsKey("antiPatternEnabled");
        cfg.trainingMode           = params.containsKey("trainingMode");
        cfg.autoKitSelect          = params.containsKey("autoKitSelect");
        cfg.bunkerEnabled          = params.containsKey("bunkerEnabled");

        // Multi-owner: добавить/удалить (ownerUUID = первый бот, упрощённо через globalOwner)
        String addNick = params.get("addCoOwner");
        String remNick = params.get("removeCoOwner");
        if (addNick != null && !addNick.isBlank() && cfg.globalOwnerUUID != null) {
            // Сервер недоступен напрямую из WebConfig, поэтому откладываем:
            cfg.pendingCoOwnerAdd = addNick.trim();
        }
        if (remNick != null && !remNick.isBlank() && cfg.globalOwnerUUID != null) {
            MultiOwner.INSTANCE.removeCoOwner(cfg.globalOwnerUUID, remNick.trim());
        }

        // Редиректим обратно на /
        ex.getResponseHeaders().set("Location", "/");
        ex.sendResponseHeaders(303, -1);
        ex.close();
    }

    // ══════════════════════════════════════════════════════════════
    //  GET /status — JSON
    // ══════════════════════════════════════════════════════════════

    private void handleStatus(HttpExchange ex) throws IOException {
        PVPBotConfig cfg = PVPBotConfig.INSTANCE;
        String json = "{" +
            "\"mode\":\"" + cfg.mode.name() + "\"," +
            "\"difficulty\":\"" + cfg.difficulty.name() + "\"," +
            "\"enabled\":" + cfg.enabled + "," +
            "\"notifications\":" + cfg.notificationsEnabled + "," +
            "\"bunker\":" + cfg.bunkerEnabled + "," +
            "\"webPort\":" + port +
        "}";
        ex.getResponseHeaders().set("Content-Type", "application/json");
        send(ex, 200, "application/json", json);
    }

    // ══════════════════════════════════════════════════════════════
    //  HTML-хелперы
    // ══════════════════════════════════════════════════════════════

    private static String selRow(String name, String label, String current, String options) {
        return "<div class='row'><label>" + label + "</label>" +
               "<select name='" + name + "'>" + options + "</select></div>";
    }

    private static String numRow(String name, String label, double val, double min, double max, double step) {
        return "<div class='row'><label>" + label + "</label>" +
               "<input type='number' name='" + name + "' value='" + val + "' min='" + min + "' max='" + max + "' step='" + step + "'></div>";
    }

    private static String checkRow(String name, String label, boolean checked) {
        return "<div class='row'><label>" + label + "</label>" +
               "<input type='checkbox' name='" + name + "'" + (checked ? " checked" : "") + "></div>";
    }

    private static String modesOptions(String current) {
        StringBuilder sb = new StringBuilder();
        for (PVPBotConfig.Mode m : PVPBotConfig.Mode.values()) {
            sb.append("<option").append(m.name().equals(current) ? " selected" : "")
              .append(">").append(m.name()).append("</option>");
        }
        return sb.toString();
    }

    private String coOwnerList() {
        if (PVPBotConfig.INSTANCE.globalOwnerUUID == null) return "<i style='color:#555'>нет владельца</i>";
        var nicks = MultiOwner.INSTANCE.getCoOwnerNicks(PVPBotConfig.INSTANCE.globalOwnerUUID);
        return nicks.isEmpty() ? "<i style='color:#555'>нет совладельцев</i>" : String.join(", ", nicks);
    }

    // ══════════════════════════════════════════════════════════════
    //  Утилиты
    // ══════════════════════════════════════════════════════════════

    private static void send(HttpExchange ex, int code, String type, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", type);
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(bytes); }
    }

    /** Парсинг URL-encoded form: key=val&key2=val2 */
    private static java.util.Map<String, String> parseForm(String body) {
        var map = new java.util.LinkedHashMap<String, String>();
        if (body == null || body.isBlank()) return map;
        for (String pair : body.split("&")) {
            String[] kv = pair.split("=", 2);
            try {
                String key = java.net.URLDecoder.decode(kv[0], StandardCharsets.UTF_8);
                String val = kv.length > 1 ? java.net.URLDecoder.decode(kv[1], StandardCharsets.UTF_8) : "";
                map.put(key, val);
            } catch (Exception ignored) {}
        }
        return map;
    }

    private static double parseDouble(String s, double def) {
        if (s == null || s.isBlank()) return def;
        try { return Double.parseDouble(s); } catch (Exception e) { return def; }
    }

    private static int parseInt(String s, int def) {
        if (s == null || s.isBlank()) return def;
        try { return Integer.parseInt(s); } catch (Exception e) { return def; }
    }
}
