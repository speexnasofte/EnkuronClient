package com.pvpbot;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

/**
 * Регистрация типа сущности бота.
 */
public class BotEntityType {

    public static final EntityType<BotEntity> BOT_ENTITY;

    static {
        BOT_ENTITY = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of("pvpbot", "pvp_bot"),
            FabricEntityTypeBuilder.<BotEntity>create(SpawnGroup.MISC, BotEntity::new)
                .dimensions(EntityDimensions.fixed(0.6f, 1.95f)) // как игрок
                .build()
        );
    }

    public static void register() {
        // Вызов этого метода инициализирует static-блок
    }
}
