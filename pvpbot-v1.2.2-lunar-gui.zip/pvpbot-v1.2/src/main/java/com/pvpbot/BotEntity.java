package com.pvpbot;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * NPC-бот: PathAwareEntity с AI-целями.
 * v7: интеграция BotDifficultyAI — EASY/MEDIUM/HARD/EXPERT поведение.
 */
public class BotEntity extends PathAwareEntity {

    private UUID ownerUUID = null;

    // v9: ник игрока чей скин носит бот (null = дефолт)
    private String skinNick = null;

    public enum BotMode { GUARD, AGGRESSIVE, PASSIVE }
    private BotMode mode = BotMode.GUARD;

    private int  nameUpdateTimer = 0;
    private int  strafeDirTimer  = 0;
    private boolean strafeLeft   = true;

    // ── v7: AI сложности ──────────────────────────────────────────
    private final BotDifficultyAI difficultyAI = new BotDifficultyAI(this);

    // ── v12: новые системы ────────────────────────────────────────
    private final StrafeAI      strafeAI      = new StrafeAI(this);
    private final PatternAI     patternAI     = new PatternAI(this);   // v14
    private final TargetPriority targetPriority = new TargetPriority(this);
    private final AutoRetreat   autoRetreat   = new AutoRetreat(this);

    // ── v14: ComboBreaker + BotNotifier ──────────────────────────
    private final ComboBreaker  comboBreaker  = new ComboBreaker(this);
    private final BotNotifier   notifier      = BotNotifier.create(this);

    // ── v15: BotBunker ────────────────────────────────────────────
    private final BotBunker     bunker        = new BotBunker(this);

    // ── v16: AdaptiveCooldown + FakeAttack + BotHunt + BotReplay ─
    private final AdaptiveCooldown adaptiveCooldown = new AdaptiveCooldown(this);
    // ── v1.2: PVPBotLogic переписан для NPC ──────────────────────
    private final PVPBotLogic      pvpLogic         = new PVPBotLogic(this);
    private final FakeAttack       fakeAttack       = new FakeAttack(this);
    private final BotHunt          botHunt          = new BotHunt(this);
    private final BotReplay        replay           = new BotReplay(this);

    public StrafeAI      getStrafeAI()      { return strafeAI; }
    public PatternAI     getPatternAI()     { return patternAI; }   // v14
    public TargetPriority getTargetPriority() { return targetPriority; }
    public AutoRetreat   getAutoRetreat()   { return autoRetreat; }
    public ComboBreaker  getComboBreaker()  { return comboBreaker; }  // v14
    public BotNotifier   getNotifier()      { return notifier; }      // v14
    public BotBunker     getBunker()        { return bunker; }        // v15
    public AdaptiveCooldown getAdaptiveCooldown() { return adaptiveCooldown; } // v16
    public PVPBotLogic     getPvpLogic()        { return pvpLogic; }         // v1.2
    public FakeAttack    getFakeAttack()    { return fakeAttack; }    // v16
    public BotHunt       getBotHunt()       { return botHunt; }       // v16
    public BotReplay     getReplay()        { return replay; }        // v16

    public BotEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world);
        this.setCanPickUpLoot(false);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return PathAwareEntity.createMobAttributes()
            .add(EntityAttributes.MAX_HEALTH,          40.0)
            .add(EntityAttributes.MOVEMENT_SPEED,       0.32)
            .add(EntityAttributes.ATTACK_DAMAGE,        7.0)
            .add(EntityAttributes.FOLLOW_RANGE,        24.0)
            .add(EntityAttributes.ARMOR,                8.0)
            .add(EntityAttributes.KNOCKBACK_RESISTANCE, 0.3);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new BotHealGoal(this));
        goalSelector.add(1, new SwimGoal(this));
        goalSelector.add(2, new BotCritMeleeGoal(this, 1.2, true));
        if (PVPBotConfig.INSTANCE.advPathfind) {
            goalSelector.add(3, new BotPathfindGoal(this, 1.1, 64.0f, 3.0f));
        } else {
            goalSelector.add(3, new BotFollowOwnerGoal(this, 1.1, 10.0f, 3.0f));
        }
        goalSelector.add(4, new WanderAroundFarGoal(this, 0.8));
        goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        goalSelector.add(6, new LookAroundGoal(this));

        targetSelector.add(1, new BotRevengeGoal(this));
        targetSelector.add(2, new BotAttackHostilesGoal(this));
        targetSelector.add(3, new BotAttackPlayersGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (!getWorld().isClient) {

            // ── Обновление имени ──────────────────────────────────
            nameUpdateTimer--;
            if (nameUpdateTimer <= 0) {
                nameUpdateTimer = 20;
                updateNameTag();
            }

            // ── v14: Тик уведомлений ──────────────────────────────
            notifier.tick();

            // ── v16: AdaptiveCooldown + Replay ────────────────────
            if (PVPBotConfig.INSTANCE.adaptiveCooldownEnabled) adaptiveCooldown.tick();
            replay.tick();

            // ── v16: BotHunt — охота на игроков ───────────────────
            if (PVPBotConfig.INSTANCE.huntEnabled && getTarget() == null) {
                botHunt.tick();
            }

            // ── v15: Pending co-owner add (из WebConfig) ──────────
            if (PVPBotConfig.INSTANCE.pendingCoOwnerAdd != null
                    && PVPBotConfig.INSTANCE.globalOwnerUUID != null
                    && getWorld() instanceof net.minecraft.server.world.ServerWorld sw15) {
                net.minecraft.server.MinecraftServer ms = sw15.getServer();
                boolean added = MultiOwner.INSTANCE.addCoOwner(
                    PVPBotConfig.INSTANCE.globalOwnerUUID,
                    PVPBotConfig.INSTANCE.pendingCoOwnerAdd, ms);
                notifier.send(added
                    ? "§a✔ Совладелец добавлен: §f" + PVPBotConfig.INSTANCE.pendingCoOwnerAdd
                    : "§c✘ Игрок не найден: §f"    + PVPBotConfig.INSTANCE.pendingCoOwnerAdd);
                PVPBotConfig.INSTANCE.pendingCoOwnerAdd = null;
            }

            // ── v15: BotBunker ────────────────────────────────────
            if (PVPBotConfig.INSTANCE.bunkerEnabled && bunker.tick()) return;

            // ── v12: TargetPriority — умный выбор цели ───────────
            targetPriority.tick();

            // ── v14: PatternAI — обновление паттернов движения цели ──
            if (getTarget() != null && PVPBotConfig.INSTANCE.patternAIEnabled) {
                patternAI.update(getTarget());
            } else if (getTarget() == null) {
                patternAI.reset();
            }

            // ── v12: AutoRetreat ──────────────────────────────────
            boolean retreating = false;
            if (getTarget() != null) {
                retreating = autoRetreat.tick(getTarget());
            }

            // ── v12: Clone mode ───────────────────────────────────
            BotClone.INSTANCE.tick(this);

            // ── Страф + BotDifficultyAI во время боя ─────────────
            if (!retreating && getTarget() != null && getTarget().isAlive()) {
                // v14: ComboBreaker — если под комбо, прерываем атаку
                if (comboBreaker.tick(getTarget())) return;

                // v16: FakeAttack тик (если активен — блокирует атаку на PAUSE_TICKS)
                if (fakeAttack.tick(getTarget())) return;

                // v12: продвинутый StrafeAI вместо простого стрейфа
                strafeAI.tick(getTarget());

                // ── v14: TrainingMode ────────────────────────────────
                if (PVPBotConfig.INSTANCE.trainingMode) {
                    TrainingMode.INSTANCE.tick(this, getTarget());
                }

                // ── v7: тик BotDifficultyAI ───────────────────────
                difficultyAI.tick(getTarget());

                // ── v1.2: PVPBotLogic (NPC) ───────────────────────
                pvpLogic.tick();

                // ── v12: синхроатака — тик (isClient уже проверен выше) ──
                {
                    var sw = (net.minecraft.server.world.ServerWorld) getWorld();
                    PlayerEntity owner = getOwner();
                    if (owner instanceof net.minecraft.server.network.ServerPlayerEntity sp) {
                        var bots = com.pvpbot.SpawnBotCommand.getBotsFor(sp);
                        BotSyncAttack.INSTANCE.serverTick(bots);
                    }
                }
            }
        }
    }

    private void updateNameTag() {
        int hp    = (int) getHealth();
        int maxHp = (int) getMaxHealth();
        String modeStr = switch (mode) {
            case GUARD      -> "§a[GUARD]";
            case AGGRESSIVE -> "§c[AGRO]";
            case PASSIVE    -> "§7[PASS]";
        };
        // v7: показываем уровень сложности в имени
        String diffStr = switch (PVPBotConfig.INSTANCE.difficulty) {
            case EASY   -> "§7[EASY]";
            case MEDIUM -> "§e[MED]";
            case HARD   -> "§c[HARD]";
            case EXPERT -> "§4§l[EXPERT]";
        };
        String bar = buildHpBar(hp, maxHp);
        setCustomName(Text.literal("§ePVP-Bot " + modeStr + " " + diffStr + "  " + bar + " §f" + hp + "§7/" + maxHp));
        setCustomNameVisible(true);
    }

    private String buildHpBar(int hp, int max) {
        if (max == 0) return "";
        int filled = Math.min(8, (int)(8.0 * hp / max));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 8; i++) {
            if (i == filled) sb.append("§c");
            else if (i == 0) sb.append("§a");
            sb.append(i < filled ? "█" : "░");
        }
        return sb.toString();
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        if (ownerUUID != null) nbt.putUuid("OwnerUUID", ownerUUID);
        nbt.putString("BotMode", mode.name());
        // v7: сохраняем сложность в NBT
        nbt.putString("BotDifficulty", PVPBotConfig.INSTANCE.difficulty.name());
        // v9: сохраняем ник скина
        if (skinNick != null) nbt.putString("SkinNick", skinNick);
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        if (nbt.containsUuid("OwnerUUID")) ownerUUID = nbt.getUuid("OwnerUUID");
        if (nbt.contains("BotMode")) {
            try { mode = BotMode.valueOf(nbt.getString("BotMode")); }
            catch (IllegalArgumentException ignored) { mode = BotMode.GUARD; }
        }
        // v7: восстанавливаем сложность из NBT и применяем
        // v9: восстанавливаем ник скина
        if (nbt.contains("SkinNick")) skinNick = nbt.getString("SkinNick");
        if (nbt.contains("BotDifficulty")) {
            try {
                PVPBotConfig.INSTANCE.difficulty =
                    PVPBotConfig.Difficulty.valueOf(nbt.getString("BotDifficulty"));
                PVPBotConfig.INSTANCE.applyDifficulty();
            } catch (IllegalArgumentException ignored) {}
        }
    }

    // ── API ───────────────────────────────────────────────────────
    public void setOwner(PlayerEntity player) { this.ownerUUID = player.getUuid(); }

    @Nullable
    public PlayerEntity getOwner() {
        if (ownerUUID == null || !(getWorld() instanceof ServerWorld sw)) return null;
        return sw.getPlayerByUuid(ownerUUID);
    }

    public BotMode getBotMode() { return mode; }

    // v9: скин
    public String getSkinNick() { return skinNick; }
    public void setSkinNick(String nick) { this.skinNick = nick; }

    public void setBotMode(BotMode m) {
        mode = m;
        setTarget(null);
        updateNameTag();
    }

    public void cycleMode() {
        mode = switch (mode) {
            case GUARD      -> BotMode.AGGRESSIVE;
            case AGGRESSIVE -> BotMode.PASSIVE;
            case PASSIVE    -> BotMode.GUARD;
        };
        setTarget(null);
        updateNameTag();
    }

    @Override
    public boolean isTeammate(net.minecraft.entity.Entity other) {
        if (other instanceof PlayerEntity p && ownerUUID != null && p.getUuid().equals(ownerUUID)) return true;
        return super.isTeammate(other);
    }

    @Override
    protected boolean isAffectedByDaylight() { return false; }

    // ── v10: AntiKnockback ────────────────────────────────────────
    @Override
    public void takeKnockback(double strength, double x, double z) {
        AntiKnockback.apply(this, strength, x, z);
    }

    @Override
    protected void knockback(net.minecraft.entity.LivingEntity attacker) {
        // Если AntiKnockback включён — подавляем стандартный обратный кнокбэк
        if (!ModuleManager.INSTANCE.isEnabled(ModuleManager.MOD_ANTI_KNOCKBACK)) {
            super.knockback(attacker);
        }
    }

    @Override
    public boolean canPickUpLoot() { return false; }

    @Override
    protected void dropEquipment(ServerWorld world, DamageSource source, boolean causedByPlayer) {}

    // ── v14: damage override для ComboBreaker + BotNotifier ──────
    @Override
    public boolean damage(ServerWorld world, DamageSource source, float amount) {
        // Сообщаем ComboBreaker об ударе
        comboBreaker.onDamageReceived(amount);

        boolean result = super.damage(world, source, amount);

        if (result) {
            // Уведомление при низком HP
            if (getHealth() < 10.0f && getHealth() > 0) {
                notifier.onLowHp();
            }
        }
        return result;
    }

    @Override
    public void onDeath(DamageSource damageSource) {
        super.onDeath(damageSource);
        // Уведомление о смерти
        net.minecraft.entity.Entity killer = damageSource.getAttacker();
        notifier.onDeath(killer instanceof LivingEntity le ? le : null);
    }
}
