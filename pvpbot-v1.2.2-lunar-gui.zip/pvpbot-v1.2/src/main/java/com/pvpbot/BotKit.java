package com.pvpbot;

import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.Item;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/**
 * BotKit — система китов для PVP-бота.
 *
 * Доступные киты:
 *   SWORD    — Netherite меч, полный нетерит, стандартный PvP
 *   CRYSTAL  — Netherite меч + End Crystal, полный нетерит, тотемы
 *   SMP      — Diamond/Iron, меч + щит + еда, выживач стиль
 *   UHC      — Diamond броня без рег, меч + лук + яблоки
 *   NETHPOT  — Iron броня + зелья, меч, potion PvP стиль
 *   AXE      — Netherite топор, полный нетерит, axe PvP
 *   TPC      — Totempot Crystal — топор + кристаллы + тотемы
 *   MACE     — Булава (Mace) + тотем, нетерит броня, mace PvP (1.21+)
 *
 * Использование: /bot kit <название>
 */
public enum BotKit {

    // ── Классический PvP ──────────────────────────────────────────
    SWORD("sword", "Netherite меч PvP",
        new KitEquipment(
            Items.NETHERITE_SWORD,       // mainhand
            null,                         // offhand
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "pvp"
    ),

    // ── Crystal PvP ───────────────────────────────────────────────
    CRYSTAL("crystal", "Crystal PvP — кристаллы + нетерит",
        new KitEquipment(
            Items.NETHERITE_SWORD,
            Items.END_CRYSTAL,            // в оффхенд визуально
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "crystal"
    ),

    // ── SMP (выживач) ─────────────────────────────────────────────
    SMP("smp", "SMP — выживач стиль, алмазная броня + щит",
        new KitEquipment(
            Items.DIAMOND_SWORD,
            Items.SHIELD,
            Items.DIAMOND_HELMET,
            Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS,
            Items.DIAMOND_BOOTS
        ),
        "smp"
    ),

    // ── UHC ───────────────────────────────────────────────────────
    UHC("uhc", "UHC — алмазы без регена, лук + яблоки",
        new KitEquipment(
            Items.DIAMOND_SWORD,
            Items.BOW,
            Items.DIAMOND_HELMET,
            Items.DIAMOND_CHESTPLATE,
            Items.DIAMOND_LEGGINGS,
            Items.DIAMOND_BOOTS
        ),
        "uhc"
    ),

    // ── NethPot (Potion PvP) ──────────────────────────────────────
    NETHPOT("nethpot", "NethPot — зелья PvP, железная броня",
        new KitEquipment(
            Items.DIAMOND_SWORD,
            Items.SPLASH_POTION,          // сплэш зелье в оффхенд
            Items.IRON_HELMET,
            Items.IRON_CHESTPLATE,
            Items.IRON_LEGGINGS,
            Items.IRON_BOOTS
        ),
        "nethpot"
    ),

    // ── Axe PvP ───────────────────────────────────────────────────
    AXE("axe", "Axe PvP — нетерит топор + щит",
        new KitEquipment(
            Items.NETHERITE_AXE,
            Items.SHIELD,
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "axe"
    ),

    // ── TPC (Totem-Pot-Crystal) ───────────────────────────────────
    TPC("tpc", "TPC — топор + кристаллы + тотемы",
        new KitEquipment(
            Items.NETHERITE_AXE,
            Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "tpc"
    ),

    // ── Mace PvP (1.21+) ─────────────────────────────────────────
    MACE("mace", "Mace PvP — булава + тотем, нетерит броня",
        new KitEquipment(
            Items.MACE,
            Items.TOTEM_OF_UNDYING,   // тотем в оффхенд для выживания
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "mace"
    ),
    // ── Beehive PvP (v14) ─────────────────────────────────────────
    BEEHIVE("beehive", "Beehive — пчёлы + мёд для регена",
        new KitEquipment(
            Items.NETHERITE_SWORD,
            Items.HONEY_BOTTLE,
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "smp"
    ),

    // ── Firework PvP (v14) ────────────────────────────────────────
    FIREWORK("firework", "Firework — фейерверки + элитры для уклонения",
        new KitEquipment(
            Items.NETHERITE_SWORD,
            Items.FIREWORK_ROCKET,
            Items.NETHERITE_HELMET,
            Items.ELYTRA,              // элитры в нагрудник
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "pvp"
    ),

    // ── Crossbow PvP (v14) ────────────────────────────────────────
    CROSSBOW("crossbow", "Crossbow — арбалет с фейерверками, burst-огонь",
        new KitEquipment(
            Items.CROSSBOW,
            Items.FIREWORK_ROCKET,
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "pvp"
    ),

    // ── Mace + Elytra комбо (v14) ────────────────────────────────
    MACE_ELYTRA("mace_elytra", "Mace+Elytra — пикирование на элитрах → smash булавой",
        new KitEquipment(
            Items.MACE,
            Items.TOTEM_OF_UNDYING,   // тотем в оффхенд
            Items.NETHERITE_HELMET,
            Items.ELYTRA,             // элитры в нагрудник
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "pvp"
    ),

    // ── Trident PvP (v14) ────────────────────────────────────────
    TRIDENT("trident", "Trident — трезубец: Channeling молния + Riptide рывок",
        new KitEquipment(
            Items.TRIDENT,
            Items.TOTEM_OF_UNDYING,
            Items.NETHERITE_HELMET,
            Items.NETHERITE_CHESTPLATE,
            Items.NETHERITE_LEGGINGS,
            Items.NETHERITE_BOOTS
        ),
        "pvp"
    );


    // ─────────────────────────────────────────────────────────────
    public final String id;
    public final String displayName;
    public final KitEquipment equipment;
    public final String profileName;  // соответствующий ModuleManager профиль

    BotKit(String id, String displayName, KitEquipment equipment, String profileName) {
        this.id          = id;
        this.displayName = displayName;
        this.equipment   = equipment;
        this.profileName = profileName;
    }

    /** Найти кит по строке (регистронезависимо). Null если не найден. */
    public static BotKit byId(String id) {
        for (BotKit kit : values()) {
            if (kit.id.equalsIgnoreCase(id)) return kit;
        }
        return null;
    }

    /** Список всех ID через запятую для подсказок. */
    public static String listIds() {
        StringBuilder sb = new StringBuilder();
        for (BotKit kit : values()) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(kit.id);
        }
        return sb.toString();
    }

    // ── Внутренний класс снаряжения ───────────────────────────────
    public static class KitEquipment {
        public final Item mainhand;
        public final Item offhand;   // null = не выдавать
        public final Item helmet;
        public final Item chestplate;
        public final Item leggings;
        public final Item boots;

        public KitEquipment(Item mainhand, Item offhand,
                            Item helmet, Item chestplate,
                            Item leggings, Item boots) {
            this.mainhand   = mainhand;
            this.offhand    = offhand;
            this.helmet     = helmet;
            this.chestplate = chestplate;
            this.leggings   = leggings;
            this.boots      = boots;
        }

        /** Применить снаряжение к боту. */
        public void applyTo(BotEntity bot) {
            if (mainhand != null)
                bot.equipStack(EquipmentSlot.MAINHAND,   new ItemStack(mainhand));
            if (offhand != null)
                bot.equipStack(EquipmentSlot.OFFHAND,    new ItemStack(offhand));
            if (helmet != null)
                bot.equipStack(EquipmentSlot.HEAD,       new ItemStack(helmet));
            if (chestplate != null)
                bot.equipStack(EquipmentSlot.CHEST,      new ItemStack(chestplate));
            if (leggings != null)
                bot.equipStack(EquipmentSlot.LEGS,       new ItemStack(leggings));
            if (boots != null)
                bot.equipStack(EquipmentSlot.FEET,       new ItemStack(boots));
        }
    }
}
