package com.pvpbot;

/**
 * AdaptiveCooldown — v16: подстройка кулдауна атаки под ping/lag сервера.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Идея:
 * ══════════════════════════════════════════════════════════════════
 *
 *  На лагающих серверах (TPS < 20) атаки бота срабатывают «в пустоту»,
 *  потому что сервер ещё не успел обработать предыдущий удар.
 *  AdaptiveCooldown следит за реальным TPS сервера и масштабирует
 *  attackCooldown в PVPBotConfig.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Алгоритм:
 * ══════════════════════════════════════════════════════════════════
 *
 *  1. Каждые SAMPLE_INTERVAL тиков фиксируем System.nanoTime().
 *  2. Из разницы времён вычисляем «реальный» TPS:
 *       realTPS = SAMPLE_INTERVAL / (elapsed_sec)
 *  3. EMA-сглаживание (exponential moving average, α=0.2)
 *  4. Если TPS < 18 → увеличиваем кулдаун на LAG_PENALTY тиков.
 *     Если TPS > 19.5 → возвращаем к базовому значению.
 *
 * ══════════════════════════════════════════════════════════════════
 *  Использование:
 * ══════════════════════════════════════════════════════════════════
 *
 *  В BotEntity.tick() добавить:
 *    adaptiveCooldown.tick();
 *
 *  В атакующей логике вместо PVPBotConfig.INSTANCE.attackCooldown
 *  использовать adaptiveCooldown.getEffectiveCooldown().
 *
 * ══════════════════════════════════════════════════════════════════
 */
public class AdaptiveCooldown {

    // ── Константы ─────────────────────────────────────────────────
    /** Тиков между замерами TPS */
    private static final int    SAMPLE_INTERVAL = 40;
    /** EMA-коэффициент сглаживания (0..1, меньше = инертнее) */
    private static final float  EMA_ALPHA       = 0.20f;
    /** TPS ниже этого — считаем «лаг» */
    private static final float  LAG_THRESHOLD   = 18.0f;
    /** TPS выше — «нормально» */
    private static final float  OK_THRESHOLD    = 19.5f;
    /** Штраф кулдауна при лаге (тиков) */
    private static final int    LAG_PENALTY     = 6;
    /** Максимальный суммарный штраф (не множим бесконечно) */
    private static final int    MAX_PENALTY     = 20;

    // ── Состояние ─────────────────────────────────────────────────
    private float smoothedTPS = 20.0f;
    private int   sampleTimer = 0;
    private long  lastNanos   = System.nanoTime();
    private int   lagPenalty  = 0;   // текущий суммарный штраф тиков

    private final BotEntity bot;

    public AdaptiveCooldown(BotEntity bot) {
        this.bot = bot;
    }

    // ══════════════════════════════════════════════════════════════
    //  Вызывать каждый тик BotEntity
    // ══════════════════════════════════════════════════════════════
    public void tick() {
        sampleTimer++;
        if (sampleTimer < SAMPLE_INTERVAL) return;
        sampleTimer = 0;

        long nowNanos  = System.nanoTime();
        double elapsed = (nowNanos - lastNanos) / 1_000_000_000.0; // сек
        lastNanos      = nowNanos;

        if (elapsed <= 0) return;

        float measuredTPS = (float) (SAMPLE_INTERVAL / elapsed);
        measuredTPS       = Math.min(measuredTPS, 20.0f); // TPS не может быть > 20

        // EMA
        smoothedTPS = EMA_ALPHA * measuredTPS + (1.0f - EMA_ALPHA) * smoothedTPS;

        // Корректируем штраф
        if (smoothedTPS < LAG_THRESHOLD) {
            // Лаг: увеличиваем penalty
            lagPenalty = Math.min(lagPenalty + LAG_PENALTY, MAX_PENALTY);
        } else if (smoothedTPS > OK_THRESHOLD) {
            // Нормально: плавно уменьшаем
            lagPenalty = Math.max(lagPenalty - 2, 0);
        }
    }

    // ══════════════════════════════════════════════════════════════
    //  Эффективный кулдаун с поправкой на lag
    // ══════════════════════════════════════════════════════════════
    public int getEffectiveCooldown() {
        int base = PVPBotConfig.INSTANCE.attackCooldown;
        return base + lagPenalty;
    }

    // ══════════════════════════════════════════════════════════════
    //  Геттеры для HUD / WebConfig
    // ══════════════════════════════════════════════════════════════
    public float getSmoothedTPS() { return smoothedTPS; }
    public int   getLagPenalty()  { return lagPenalty;  }

    public boolean isLagging() { return smoothedTPS < LAG_THRESHOLD; }

    /** Метка для HUD */
    public String getLabel() {
        if (lagPenalty == 0) return "";
        return String.format("§eLAG:+%dt §7(TPS=%.1f)", lagPenalty, smoothedTPS);
    }
}
